package proyectoprincipal;

import java.awt.Dimension;

import java.awt.Rectangle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;

public class VerEliminarComponentes extends JFrame {
    private JButton jButton1 = new JButton();
    private JList jList1 = new JList();
    private JComboBox jComboBox1 = new JComboBox();
    private JButton jButton2 = new JButton();
    private JLabel jLabel1 = new JLabel();

    public VerEliminarComponentes() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout( null );
        this.setSize(new Dimension(562, 372));
        this.setTitle( "Ver o Eliminar Componentes" );
        jButton1.setText("Volver");
        jButton1.setBounds(new Rectangle(230, 300, 75, 21));
        jButton1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton1_actionPerformed(e);
                }
            });
        jList1.setBounds(new Rectangle(25, 20, 510, 175));
        jComboBox1.setBounds(new Rectangle(150, 230, 380, 20));
        jButton2.setText("Eliminar Componente");
        jButton2.setBounds(new Rectangle(390, 260, 140, 20));
        jLabel1.setText("Seleccione el componente:");
        jLabel1.setBounds(new Rectangle(15, 235, 130, 15));
        this.getContentPane().add(jLabel1, null);
        this.getContentPane().add(jButton2, null);
        this.getContentPane().add(jComboBox1, null);
        this.getContentPane().add(jList1, null);
        this.getContentPane().add(jButton1, null);
    }

    private void jButton1_actionPerformed(ActionEvent e) {
        Principal nuevaVentana = new Principal();
        nuevaVentana.setVisible(true);
        this.dispose();
        
    }
}
