package proyectoprincipal;

import java.awt.Dimension;

import java.awt.Rectangle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class CrearArticulo extends JFrame {
    private JButton jButton1 = new JButton();
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel5 = new JLabel();
    private JLabel jLabel6 = new JLabel();
    private JLabel jLabel7 = new JLabel();
    private JLabel jLabel8 = new JLabel();
    private JLabel jLabel9 = new JLabel();
    private JLabel jLabel10 = new JLabel();
    private JLabel jLabel11 = new JLabel();
    private JLabel jLabel12 = new JLabel();
    private JTextField jTextField1 = new JTextField();
    private JTextField jTextField2 = new JTextField();
    private JComboBox jComboBox1 = new JComboBox();
    private JComboBox jComboBox2 = new JComboBox();
    private JTextField jTextField3 = new JTextField();
    private JComboBox jComboBox3 = new JComboBox();
    private JComboBox jComboBox4 = new JComboBox();
    private JTextField jTextField4 = new JTextField();
    private JTextField jTextField5 = new JTextField();
    private JTextField jTextField6 = new JTextField();
    private JTextField jTextField7 = new JTextField();
    private JButton jButton2 = new JButton();

    public CrearArticulo() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout( null );
        this.setSize(new Dimension(607, 224));
        this.setTitle( "Crear Articulo" );
        jButton1.setText("Volver");
        jButton1.setBounds(new Rectangle(320, 155, 75, 21));
        jButton1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton1_actionPerformed(e);
                }
            });
        jLabel1.setText("Codigo:");
        jLabel1.setBounds(new Rectangle(55, 50, 50, 15));
        jLabel2.setText("Descripcion:");
        jLabel2.setBounds(new Rectangle(35, 20, 65, 15));
        jLabel3.setText("Unidad de Medida:");
        jLabel3.setBounds(new Rectangle(5, 80, 100, 15));
        jLabel4.setText("jLabel1");
        jLabel5.setText("Marca:");
        jLabel5.setBounds(new Rectangle(60, 110, 34, 14));
        jLabel6.setText("Modelo:");
        jLabel6.setBounds(new Rectangle(220, 50, 45, 15));
        jLabel7.setText("Familia:");
        jLabel7.setBounds(new Rectangle(220, 80, 55, 15));
        jLabel8.setText("Estado:");
        jLabel8.setBounds(new Rectangle(220, 110, 45, 15));
        jLabel9.setText("Cantidad:");
        jLabel9.setBounds(new Rectangle(440, 20, 60, 15));
        jLabel10.setText("Cantidad Maxima:");
        jLabel10.setBounds(new Rectangle(400, 50, 115, 15));
        jLabel11.setText("Cantidad Minima:");
        jLabel11.setBounds(new Rectangle(405, 80, 105, 15));
        jLabel12.setText("Precio en Dolares:");
        jLabel12.setBounds(new Rectangle(400, 110, 90, 15));
        jTextField1.setBounds(new Rectangle(95, 45, 105, 20));
        jTextField2.setBounds(new Rectangle(95, 15, 275, 20));
        jComboBox1.setBounds(new Rectangle(95, 75, 105, 20));
        jComboBox2.setBounds(new Rectangle(95, 105, 105, 20));
        jTextField3.setBounds(new Rectangle(260, 45, 110, 20));
        jComboBox3.setBounds(new Rectangle(260, 75, 110, 20));
        jComboBox4.setBounds(new Rectangle(260, 105, 110, 20));
        jTextField4.setBounds(new Rectangle(490, 15, 80, 20));
        jTextField5.setBounds(new Rectangle(490, 45, 80, 20));
        jTextField6.setBounds(new Rectangle(490, 75, 80, 20));
        jTextField7.setBounds(new Rectangle(490, 105, 80, 20));
        jButton2.setText("Crear Articulo");
        jButton2.setBounds(new Rectangle(195, 155, 110, 20));
        jTextField3.setBounds(new Rectangle(260, 45, 110, 20));
        this.getContentPane().add(jTextField3, null);
        this.getContentPane().add(jButton2, null);
        this.getContentPane().add(jTextField7, null);
        this.getContentPane().add(jTextField6, null);
        this.getContentPane().add(jTextField5, null);
        this.getContentPane().add(jTextField4, null);
        this.getContentPane().add(jComboBox4, null);
        this.getContentPane().add(jComboBox3, null);
        this.getContentPane().add(jTextField3, null);
        this.getContentPane().add(jComboBox2, null);
        this.getContentPane().add(jComboBox1, null);
        this.getContentPane().add(jTextField2, null);
        this.getContentPane().add(jTextField1, null);
        this.getContentPane().add(jLabel12, null);
        this.getContentPane().add(jLabel11, null);
        this.getContentPane().add(jLabel10, null);
        this.getContentPane().add(jLabel9, null);
        this.getContentPane().add(jLabel8, null);
        this.getContentPane().add(jLabel7, null);
        this.getContentPane().add(jLabel6, null);
        this.getContentPane().add(jLabel5, null);
        this.getContentPane().add(jLabel3, null);
        this.getContentPane().add(jLabel2, null);
        this.getContentPane().add(jLabel1, null);
        this.getContentPane().add(jButton1, null);
    }

    private void jButton1_actionPerformed(ActionEvent e) {
        Principal nuevaVentana = new Principal();
        nuevaVentana.setVisible(true);
        this.dispose();
    }
}
