package proyectoprincipal;

import java.math.BigDecimal;


/**
 * Definida para almacenar localmente el codigo
 * y la descripcion de un objeto residente
 * en la base de datos.
 */
public class ComboItem {
    
    //Identificador String del Objeto
    public String codigoStr = "";
    public BigDecimal codigoInt = new BigDecimal(0);
    public String dato = "";
    
    public ComboItem(String pCod, String pValor) {
        super();
        this.codigoStr = pCod;
        this.dato = pValor;
    }//End Constructor
    
    public ComboItem(BigDecimal pCod, String pValor) {
        super();
        this.codigoInt = pCod;
        this.dato = pValor;
    }//End Constructor
    
    public String getCodigoStr(){
        return this.codigoStr;
    }//End Method
    
    public BigDecimal getCodigoInt(){
        return this.codigoInt;
    }//End Method
    
    public String getDescripcion(){
        return this.dato;
    }//End Method
    
}//End Class
