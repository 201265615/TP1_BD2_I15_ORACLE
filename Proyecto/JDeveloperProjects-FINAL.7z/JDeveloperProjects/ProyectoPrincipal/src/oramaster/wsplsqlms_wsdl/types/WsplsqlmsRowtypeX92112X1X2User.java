
package oramaster.wsplsqlms_wsdl.types;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for WsplsqlmsRowtypeX92112x1x2User complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WsplsqlmsRowtypeX92112x1x2User">
 *   &lt;complexContent>
 *     &lt;extension base="{http://oramaster/WSPLSQLMS.wsdl/types/}WsplsqlmsRowtypeX92112x1x2Base">
 *       &lt;sequence>
 *         &lt;element name="cantminima" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="descripcion" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="preciomercdolares" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="codfamilia" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="cantmaxima" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="codigo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="fecregistro" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="fechaactprecio" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="cantidad" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="codmarca" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="codestarticulo" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="coduserregistro" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="undmedida" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="modelo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WsplsqlmsRowtypeX92112x1x2User", propOrder = {
    "cantminima",
    "descripcion",
    "preciomercdolares",
    "codfamilia",
    "cantmaxima",
    "codigo",
    "fecregistro",
    "fechaactprecio",
    "cantidad",
    "codmarca",
    "codestarticulo",
    "coduserregistro",
    "undmedida",
    "modelo"
})
public class WsplsqlmsRowtypeX92112X1X2User
    extends WsplsqlmsRowtypeX92112X1X2Base
{

    @XmlElement(required = true, nillable = true)
    protected BigDecimal cantminima;
    @XmlElement(required = true, nillable = true)
    protected String descripcion;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal preciomercdolares;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal codfamilia;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal cantmaxima;
    @XmlElement(required = true, nillable = true)
    protected String codigo;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar fecregistro;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar fechaactprecio;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal cantidad;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal codmarca;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal codestarticulo;
    @XmlElement(required = true, nillable = true)
    protected String coduserregistro;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal undmedida;
    @XmlElement(required = true, nillable = true)
    protected String modelo;

    /**
     * Gets the value of the cantminima property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCantminima() {
        return cantminima;
    }

    /**
     * Sets the value of the cantminima property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCantminima(BigDecimal value) {
        this.cantminima = value;
    }

    /**
     * Gets the value of the descripcion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Sets the value of the descripcion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescripcion(String value) {
        this.descripcion = value;
    }

    /**
     * Gets the value of the preciomercdolares property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPreciomercdolares() {
        return preciomercdolares;
    }

    /**
     * Sets the value of the preciomercdolares property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPreciomercdolares(BigDecimal value) {
        this.preciomercdolares = value;
    }

    /**
     * Gets the value of the codfamilia property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCodfamilia() {
        return codfamilia;
    }

    /**
     * Sets the value of the codfamilia property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCodfamilia(BigDecimal value) {
        this.codfamilia = value;
    }

    /**
     * Gets the value of the cantmaxima property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCantmaxima() {
        return cantmaxima;
    }

    /**
     * Sets the value of the cantmaxima property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCantmaxima(BigDecimal value) {
        this.cantmaxima = value;
    }

    /**
     * Gets the value of the codigo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * Sets the value of the codigo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigo(String value) {
        this.codigo = value;
    }

    /**
     * Gets the value of the fecregistro property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFecregistro() {
        return fecregistro;
    }

    /**
     * Sets the value of the fecregistro property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFecregistro(XMLGregorianCalendar value) {
        this.fecregistro = value;
    }

    /**
     * Gets the value of the fechaactprecio property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFechaactprecio() {
        return fechaactprecio;
    }

    /**
     * Sets the value of the fechaactprecio property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaactprecio(XMLGregorianCalendar value) {
        this.fechaactprecio = value;
    }

    /**
     * Gets the value of the cantidad property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCantidad() {
        return cantidad;
    }

    /**
     * Sets the value of the cantidad property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCantidad(BigDecimal value) {
        this.cantidad = value;
    }

    /**
     * Gets the value of the codmarca property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCodmarca() {
        return codmarca;
    }

    /**
     * Sets the value of the codmarca property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCodmarca(BigDecimal value) {
        this.codmarca = value;
    }

    /**
     * Gets the value of the codestarticulo property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCodestarticulo() {
        return codestarticulo;
    }

    /**
     * Sets the value of the codestarticulo property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCodestarticulo(BigDecimal value) {
        this.codestarticulo = value;
    }

    /**
     * Gets the value of the coduserregistro property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoduserregistro() {
        return coduserregistro;
    }

    /**
     * Sets the value of the coduserregistro property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoduserregistro(String value) {
        this.coduserregistro = value;
    }

    /**
     * Gets the value of the undmedida property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getUndmedida() {
        return undmedida;
    }

    /**
     * Sets the value of the undmedida property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setUndmedida(BigDecimal value) {
        this.undmedida = value;
    }

    /**
     * Gets the value of the modelo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * Sets the value of the modelo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModelo(String value) {
        this.modelo = value;
    }

}
