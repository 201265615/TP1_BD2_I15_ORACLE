
package oramaster.wsplsqlms_wsdl.types;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the oramaster.wsplsqlms_wsdl.types package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: oramaster.wsplsqlms_wsdl.types
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link WsplsqlmsRowtypeX92112X1X2Base }
     * 
     */
    public WsplsqlmsRowtypeX92112X1X2Base createWsplsqlmsRowtypeX92112X1X2Base() {
        return new WsplsqlmsRowtypeX92112X1X2Base();
    }

    /**
     * Create an instance of {@link WsplsqlmsRowtypeX92112X1X2User }
     * 
     */
    public WsplsqlmsRowtypeX92112X1X2User createWsplsqlmsRowtypeX92112X1X2User() {
        return new WsplsqlmsRowtypeX92112X1X2User();
    }

    /**
     * Create an instance of {@link WsplsqlmsRowtypeX92112X1X2UserArray }
     * 
     */
    public WsplsqlmsRowtypeX92112X1X2UserArray createWsplsqlmsRowtypeX92112X1X2UserArray() {
        return new WsplsqlmsRowtypeX92112X1X2UserArray();
    }

}
