package oraserveri;

import java.sql.SQLException;
import java.sql.Connection;
import java.io.*;

public class WSPLSQLUser extends WSPLSQLBase implements WSPLSQL, java.rmi.Remote
{

 /* constructors */
 public WSPLSQLUser() throws SQLException  { super(); }
 public WSPLSQLUser(javax.sql.DataSource ds) throws SQLException { super(ds); }
 /* superclass methods */
  public WsplsqlRecarticuloUser funGetarticulosV3() throws java.rmi.RemoteException
  { 

 WsplsqlRecarticuloUser __jRt_0 = null;
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
    __jRt_0 = super._funGetarticulosV3(__onnScopeMethod);
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
    return __jRt_0;
  }
  public void spBorrarcomponente(String inCodcomponente, String inCodarticulo) throws java.rmi.RemoteException
  { 
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
 String __jRt_3 = inCodarticulo;
 String __jRt_2 = inCodcomponente;
    super._spBorrarcomponente(__jRt_2, __jRt_3, __onnScopeMethod);
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
  }
  public void spGetarticulos() throws java.rmi.RemoteException
  { 
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
    super._spGetarticulos(__onnScopeMethod);
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
  }
  public void spGetcomponentes() throws java.rmi.RemoteException
  { 
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
    super._spGetcomponentes(__onnScopeMethod);
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
  }
  public void spInsertararticulo(String inCodigo, String inDescripcion, java.math.BigDecimal inUndmedida, java.math.BigDecimal inCodmarca, String inModelo, java.math.BigDecimal inCodfamilia, java.math.BigDecimal inCodestarticulo, String inCoduserregistro, java.math.BigDecimal inCantidad, java.math.BigDecimal inCantmaxima, java.math.BigDecimal inCantminima, java.math.BigDecimal inPreciomercdolares) throws java.rmi.RemoteException
  { 
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
 java.math.BigDecimal __jRt_17 = inPreciomercdolares;
 java.math.BigDecimal __jRt_16 = inCantminima;
 java.math.BigDecimal __jRt_15 = inCantmaxima;
 java.math.BigDecimal __jRt_14 = inCantidad;
 String __jRt_13 = inCoduserregistro;
 java.math.BigDecimal __jRt_12 = inCodestarticulo;
 java.math.BigDecimal __jRt_11 = inCodfamilia;
 String __jRt_10 = inModelo;
 java.math.BigDecimal __jRt_9 = inCodmarca;
 java.math.BigDecimal __jRt_8 = inUndmedida;
 String __jRt_7 = inDescripcion;
 String __jRt_6 = inCodigo;
    super._spInsertararticulo(__jRt_6, __jRt_7, __jRt_8, __jRt_9, __jRt_10, __jRt_11, __jRt_12, __jRt_13, __jRt_14, __jRt_15, __jRt_16, __jRt_17, __onnScopeMethod);
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
  }
  public void spInsertarcomponente(String inCodigocomponente, String inCodigoarticulo) throws java.rmi.RemoteException
  { 
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
 String __jRt_31 = inCodigoarticulo;
 String __jRt_30 = inCodigocomponente;
    super._spInsertarcomponente(__jRt_30, __jRt_31, __onnScopeMethod);
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
  }
  public void spModificararticulo(String inCodigo, String inCoduserregistro, java.math.BigDecimal inPreciomercdolares) throws java.rmi.RemoteException
  { 
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
 java.math.BigDecimal __jRt_36 = inPreciomercdolares;
 String __jRt_35 = inCoduserregistro;
 String __jRt_34 = inCodigo;
    super._spModificararticulo(__jRt_34, __jRt_35, __jRt_36, __onnScopeMethod);
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
  }
  public void spModificarcomponente(String inCodcomponente, String inCodarticulo) throws java.rmi.RemoteException
  { 
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
 String __jRt_41 = inCodarticulo;
 String __jRt_40 = inCodcomponente;
    super._spModificarcomponente(__jRt_40, __jRt_41, __onnScopeMethod);
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
  }
}
