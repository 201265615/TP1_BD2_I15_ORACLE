package oraserveri;

import java.sql.SQLException;
import java.sql.Connection;
import java.io.*;

public class WSPLSQLBase
{

  /* connection management */
  protected javax.sql.DataSource __dataSource = null;
 public void _setDataSource(javax.sql.DataSource dataSource) throws SQLException
  { __dataSource = dataSource; }
 public void _setDataSourceLocation(String dataSourceLocation) throws SQLException {
 javax.sql.DataSource dataSource;
 try {
 Class cls = Class.forName("javax.naming.InitialContext");
 Object ctx = cls.newInstance();
 java.lang.reflect.Method meth = cls.getMethod("lookup", new Class[]{String.class});
 dataSource = (javax.sql.DataSource) meth.invoke(ctx, new Object[]{"java:comp/env/" + dataSourceLocation});
 _setDataSource(dataSource);
 } catch (Exception e) {
 throw new java.sql.SQLException("Error initializing DataSource at " + dataSourceLocation + ": " + e.getMessage());
 }
  }

 /* constructors */
 public WSPLSQLBase() throws SQLException
  {  try {
 javax.naming.InitialContext __initCtx = new javax.naming.InitialContext();
 __dataSource = (javax.sql.DataSource) __initCtx.lookup("java:comp/env/jdbc/oraserveriDS");
 } catch (Exception __jndie) { 
 throw new java.sql.SQLException("Error looking up <java:comp/env/jdbc/oraserveriDS>: " + __jndie.getMessage()); 
   }
 }
 public WSPLSQLBase(javax.sql.DataSource ds) throws SQLException { __dataSource = ds; }

  protected WsplsqlRecarticuloUser _funGetarticulosV3 (Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
 WsplsqlRecarticuloUser __jPt_result=null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN :1 := WSPLSQL_plsql_wrapper.PL_TO_SQL0(\"PKG_ARTICULO\".FUN_GETARTICULOS_V3()); END;");
    __sJT_st.registerOutParameter(1, 2002, "WSPLSQL_RECARTICULO");
    __sJT_st.executeUpdate();
    __jPt_result = (WsplsqlRecarticuloUser) __sJT_st.getORAData(1, WsplsqlRecarticuloUser.getORADataFactory());
    try { __sJT_st.close(); } catch (Exception e) {}
    return __jPt_result;
  }

  protected void _spBorrarcomponente (
    String IN_CODCOMPONENTE,
    String IN_CODARTICULO, Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN \"PKG_ARTICULO\".SP_BORRARCOMPONENTE(:1 ,:2 ); END;");
 if (IN_CODCOMPONENTE==null) __sJT_st.setNull(1, 12); else __sJT_st.setString(1, IN_CODCOMPONENTE);
 if (IN_CODARTICULO==null) __sJT_st.setNull(2, 12); else __sJT_st.setString(2, IN_CODARTICULO);
    __sJT_st.executeUpdate();
    try { __sJT_st.close(); } catch (Exception e) {}
  }

  protected void _spGetarticulos (Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN \"PKG_ARTICULO\".SP_GETARTICULOS(); END;");
    __sJT_st.executeUpdate();
    try { __sJT_st.close(); } catch (Exception e) {}
  }

  protected void _spGetcomponentes (Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN \"PKG_ARTICULO\".SP_GETCOMPONENTES(); END;");
    __sJT_st.executeUpdate();
    try { __sJT_st.close(); } catch (Exception e) {}
  }

  protected void _spInsertararticulo (
    String IN_CODIGO,
    String IN_DESCRIPCION,
    java.math.BigDecimal IN_UNDMEDIDA,
    java.math.BigDecimal IN_CODMARCA,
    String IN_MODELO,
    java.math.BigDecimal IN_CODFAMILIA,
    java.math.BigDecimal IN_CODESTARTICULO,
    String IN_CODUSERREGISTRO,
    java.math.BigDecimal IN_CANTIDAD,
    java.math.BigDecimal IN_CANTMAXIMA,
    java.math.BigDecimal IN_CANTMINIMA,
    java.math.BigDecimal IN_PRECIOMERCDOLARES, Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN \"PKG_ARTICULO\".SP_INSERTARARTICULO(:1 ,:2 ,:3 ,:4 ,:5 ,:6 ,:7 ,:8 ,:9 ,:10 ,:11 ,:12 ); END;");
 if (IN_CODIGO==null) __sJT_st.setNull(1, 12); else __sJT_st.setString(1, IN_CODIGO);
 if (IN_DESCRIPCION==null) __sJT_st.setNull(2, 12); else __sJT_st.setString(2, IN_DESCRIPCION);
 if (IN_UNDMEDIDA==null) __sJT_st.setNull(3, 2); else __sJT_st.setBigDecimal(3, IN_UNDMEDIDA);
 if (IN_CODMARCA==null) __sJT_st.setNull(4, 2); else __sJT_st.setBigDecimal(4, IN_CODMARCA);
 if (IN_MODELO==null) __sJT_st.setNull(5, 12); else __sJT_st.setString(5, IN_MODELO);
 if (IN_CODFAMILIA==null) __sJT_st.setNull(6, 2); else __sJT_st.setBigDecimal(6, IN_CODFAMILIA);
 if (IN_CODESTARTICULO==null) __sJT_st.setNull(7, 2); else __sJT_st.setBigDecimal(7, IN_CODESTARTICULO);
 if (IN_CODUSERREGISTRO==null) __sJT_st.setNull(8, 12); else __sJT_st.setString(8, IN_CODUSERREGISTRO);
 if (IN_CANTIDAD==null) __sJT_st.setNull(9, 2); else __sJT_st.setBigDecimal(9, IN_CANTIDAD);
 if (IN_CANTMAXIMA==null) __sJT_st.setNull(10, 2); else __sJT_st.setBigDecimal(10, IN_CANTMAXIMA);
 if (IN_CANTMINIMA==null) __sJT_st.setNull(11, 2); else __sJT_st.setBigDecimal(11, IN_CANTMINIMA);
 if (IN_PRECIOMERCDOLARES==null) __sJT_st.setNull(12, 2); else __sJT_st.setBigDecimal(12, IN_PRECIOMERCDOLARES);
    __sJT_st.executeUpdate();
    try { __sJT_st.close(); } catch (Exception e) {}
  }

  protected void _spInsertarcomponente (
    String IN_CODIGOCOMPONENTE,
    String IN_CODIGOARTICULO, Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN \"PKG_ARTICULO\".SP_INSERTARCOMPONENTE(:1 ,:2 ); END;");
 if (IN_CODIGOCOMPONENTE==null) __sJT_st.setNull(1, 12); else __sJT_st.setString(1, IN_CODIGOCOMPONENTE);
 if (IN_CODIGOARTICULO==null) __sJT_st.setNull(2, 12); else __sJT_st.setString(2, IN_CODIGOARTICULO);
    __sJT_st.executeUpdate();
    try { __sJT_st.close(); } catch (Exception e) {}
  }

  protected void _spModificararticulo (
    String IN_CODIGO,
    String IN_CODUSERREGISTRO,
    java.math.BigDecimal IN_PRECIOMERCDOLARES, Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN \"PKG_ARTICULO\".SP_MODIFICARARTICULO(:1 ,:2 ,:3 ); END;");
 if (IN_CODIGO==null) __sJT_st.setNull(1, 12); else __sJT_st.setString(1, IN_CODIGO);
 if (IN_CODUSERREGISTRO==null) __sJT_st.setNull(2, 12); else __sJT_st.setString(2, IN_CODUSERREGISTRO);
 if (IN_PRECIOMERCDOLARES==null) __sJT_st.setNull(3, 2); else __sJT_st.setBigDecimal(3, IN_PRECIOMERCDOLARES);
    __sJT_st.executeUpdate();
    try { __sJT_st.close(); } catch (Exception e) {}
  }

  protected void _spModificarcomponente (
    String IN_CODCOMPONENTE,
    String IN_CODARTICULO, Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN \"PKG_ARTICULO\".SP_MODIFICARCOMPONENTE(:1 ,:2 ); END;");
 if (IN_CODCOMPONENTE==null) __sJT_st.setNull(1, 12); else __sJT_st.setString(1, IN_CODCOMPONENTE);
 if (IN_CODARTICULO==null) __sJT_st.setNull(2, 12); else __sJT_st.setString(2, IN_CODARTICULO);
    __sJT_st.executeUpdate();
    try { __sJT_st.close(); } catch (Exception e) {}
  }
}
