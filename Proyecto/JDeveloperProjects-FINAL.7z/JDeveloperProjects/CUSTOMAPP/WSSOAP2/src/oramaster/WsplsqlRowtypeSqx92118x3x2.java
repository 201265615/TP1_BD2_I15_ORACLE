package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public interface WsplsqlRowtypeSqx92118x3x2 {

 public void setCodigo(java.math.BigDecimal codigo) throws SQLException;
 public java.math.BigDecimal getCodigo() throws SQLException;

 public void setDescripcion(String descripcion) throws SQLException;
 public String getDescripcion() throws SQLException;


}
