package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public class WsplsqlRowtypeSqx92118x4x2User extends WsplsqlRowtypeSqx92118x4x2Base implements ORAData, ORADataFactory, WsplsqlRowtypeSqx92118x4x2
{
 private static final WsplsqlRowtypeSqx92118x4x2User _WsplsqlRowtypeSqx92118x4x2UserFactory = new WsplsqlRowtypeSqx92118x4x2User();
 public static ORADataFactory getORADataFactory()
   { return _WsplsqlRowtypeSqx92118x4x2UserFactory; }

   public WsplsqlRowtypeSqx92118x4x2User() { super(); }
 public WsplsqlRowtypeSqx92118x4x2User(java.math.BigDecimal codigo, String descripcion, java.math.BigDecimal porcimpacompra, java.math.BigDecimal codindiceeconomico) throws SQLException
 {
 _setCodigo(codigo);
 _setDescripcion(descripcion);
 _setPorcimpacompra(porcimpacompra);
 _setCodindiceeconomico(codindiceeconomico);
  }
 /* ORAData interface */
 public ORAData create(Datum d, int sqlType) throws SQLException
 { return create(new WsplsqlRowtypeSqx92118x4x2User(), d, sqlType); }

  /* superclass accessors */

 public void setCodigo(java.math.BigDecimal codigo) throws SQLException { super._setCodigo(codigo); }
 public java.math.BigDecimal getCodigo() throws SQLException { return super._getCodigo(); }


 public void setDescripcion(String descripcion) throws SQLException { super._setDescripcion(descripcion); }
 public String getDescripcion() throws SQLException { return super._getDescripcion(); }


 public void setPorcimpacompra(java.math.BigDecimal porcimpacompra) throws SQLException { super._setPorcimpacompra(porcimpacompra); }
 public java.math.BigDecimal getPorcimpacompra() throws SQLException { return super._getPorcimpacompra(); }


 public void setCodindiceeconomico(java.math.BigDecimal codindiceeconomico) throws SQLException { super._setCodindiceeconomico(codindiceeconomico); }
 public java.math.BigDecimal getCodindiceeconomico() throws SQLException { return super._getCodindiceeconomico(); }



}
