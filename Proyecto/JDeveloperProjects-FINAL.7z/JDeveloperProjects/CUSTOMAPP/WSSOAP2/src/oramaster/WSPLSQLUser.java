package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import java.io.*;

public class WSPLSQLUser extends WSPLSQLBase implements WSPLSQL, java.rmi.Remote
{

 /* constructors */
 public WSPLSQLUser() throws SQLException  { super(); }
 public WSPLSQLUser(javax.sql.DataSource ds) throws SQLException { super(ds); }
 /* superclass methods */
  public WsplsqlRowtypeSqx92118x1x2User[] listarticulos() throws java.rmi.RemoteException
  { 

 WsplsqlArrarticulos __jRt_0 = null;

 WsplsqlRowtypeSqx92118x1x2User[] __jRt_0x = null;
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
    __jRt_0 = super._listarticulos(__onnScopeMethod);

    __jRt_0x = __jRt_0.getArray();
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
    return __jRt_0x;
  }
  public WsplsqlRowtypeSqx92118x5x2User[] listcomponentes() throws java.rmi.RemoteException
  { 

 WsplsqlArrcomponentes __jRt_0 = null;

 WsplsqlRowtypeSqx92118x5x2User[] __jRt_0x = null;
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
    __jRt_0 = super._listcomponentes(__onnScopeMethod);

    __jRt_0x = __jRt_0.getArray();
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
    return __jRt_0x;
  }
  public WsplsqlRowtypeSqx92118x4x2User[] listfamilias() throws java.rmi.RemoteException
  { 

 WsplsqlArrfamilias __jRt_0 = null;

 WsplsqlRowtypeSqx92118x4x2User[] __jRt_0x = null;
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
    __jRt_0 = super._listfamilias(__onnScopeMethod);

    __jRt_0x = __jRt_0.getArray();
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
    return __jRt_0x;
  }
  public WsplsqlRowtypeSqx92118x3x2User[] listmarcas() throws java.rmi.RemoteException
  { 

 WsplsqlArrmarcas __jRt_0 = null;

 WsplsqlRowtypeSqx92118x3x2User[] __jRt_0x = null;
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
    __jRt_0 = super._listmarcas(__onnScopeMethod);

    __jRt_0x = __jRt_0.getArray();
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
    return __jRt_0x;
  }
  public WsplsqlRowtypeSqx92118x7x2User[] listproylistaprecios() throws java.rmi.RemoteException
  { 

 WsplsqlArrproylistaprecios __jRt_0 = null;

 WsplsqlRowtypeSqx92118x7x2User[] __jRt_0x = null;
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
    __jRt_0 = super._listproylistaprecios(__onnScopeMethod);

    __jRt_0x = __jRt_0.getArray();
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
    return __jRt_0x;
  }
  public WsplsqlRowtypeSqx92118x6x2User[] listtipocambios() throws java.rmi.RemoteException
  { 

 WsplsqlArrtipocambios __jRt_0 = null;

 WsplsqlRowtypeSqx92118x6x2User[] __jRt_0x = null;
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
    __jRt_0 = super._listtipocambios(__onnScopeMethod);

    __jRt_0x = __jRt_0.getArray();
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
    return __jRt_0x;
  }
  public WsplsqlRowtypeSqx92118x2x2User[] listunidmedidas() throws java.rmi.RemoteException
  { 

 WsplsqlArrunidmedidas __jRt_0 = null;

 WsplsqlRowtypeSqx92118x2x2User[] __jRt_0x = null;
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
    __jRt_0 = super._listunidmedidas(__onnScopeMethod);

    __jRt_0x = __jRt_0.getArray();
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
    return __jRt_0x;
  }
}
