package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public class WsplsqlRowtypeSqx92118x4x2Base implements ORAData, ORADataFactory
{
 public static final String _SQL_NAME = "WSPLSQL_ROWTYPE_SQX92118X4X2";
  public static final int _SQL_TYPECODE = OracleTypes.STRUCT;

 protected MutableStruct _struct;

 protected static int[] _sqlType =  { 2,12,2,2 };
 protected static ORADataFactory[] _factory = new ORADataFactory[4];
 protected static final WsplsqlRowtypeSqx92118x4x2Base _WsplsqlRowtypeSqx92118x4x2BaseFactory = new WsplsqlRowtypeSqx92118x4x2Base();

 public static ORADataFactory getORADataFactory()
  { return _WsplsqlRowtypeSqx92118x4x2BaseFactory; }
 /* constructors */
 protected void _init_struct(boolean init)
 { if (init) _struct = new MutableStruct(new Object[4], _sqlType, _factory); }
 public WsplsqlRowtypeSqx92118x4x2Base()
 { _init_struct(true); }
 public WsplsqlRowtypeSqx92118x4x2Base(java.math.BigDecimal codigo, String descripcion, java.math.BigDecimal porcimpacompra, java.math.BigDecimal codindiceeconomico) throws SQLException
 { _init_struct(true);
 _setCodigo(codigo);
 _setDescripcion(descripcion);
 _setPorcimpacompra(porcimpacompra);
 _setCodindiceeconomico(codindiceeconomico);
  }

 /* ORAData interface */
 public Datum toDatum(Connection c) throws SQLException
  {
 _userSetterHelper();
    return _struct.toDatum(c, _SQL_NAME);
 }


 /* ORADataFactory interface */
 public ORAData create(Datum d, int sqlType) throws SQLException
 { return create(null, d, sqlType); }
 protected ORAData create(WsplsqlRowtypeSqx92118x4x2Base o, Datum d, int sqlType) throws SQLException
  {
 if (d == null) return null; 
    if (o == null) o = new WsplsqlRowtypeSqx92118x4x2User();
 o._struct = new MutableStruct((STRUCT) d, _sqlType, _factory);
    return o;
  }
 /* accessor methods */
 protected java.math.BigDecimal _getCodigo() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(0); }

 protected void _setCodigo(java.math.BigDecimal codigo) throws SQLException
  { _struct.setAttribute(0, codigo); }


 protected String _getDescripcion() throws SQLException
 { return (String) _struct.getAttribute(1); }

 protected void _setDescripcion(String descripcion) throws SQLException
  { _struct.setAttribute(1, descripcion); }


 protected java.math.BigDecimal _getPorcimpacompra() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(2); }

 protected void _setPorcimpacompra(java.math.BigDecimal porcimpacompra) throws SQLException
  { _struct.setAttribute(2, porcimpacompra); }


 protected java.math.BigDecimal _getCodindiceeconomico() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(3); }

 protected void _setCodindiceeconomico(java.math.BigDecimal codindiceeconomico) throws SQLException
  { _struct.setAttribute(3, codindiceeconomico); }

;
  // Some setter action is delayed until toDatum() 
  // where the connection is available 
  void _userSetterHelper() throws java.sql.SQLException {} 
}
