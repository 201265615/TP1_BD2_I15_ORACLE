package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import java.io.*;

public interface WSPLSQL extends java.rmi.Remote{


  public WsplsqlRowtypeSqx92118x1x2User[] listarticulos() throws java.rmi.RemoteException;
  public WsplsqlRowtypeSqx92118x5x2User[] listcomponentes() throws java.rmi.RemoteException;
  public WsplsqlRowtypeSqx92118x4x2User[] listfamilias() throws java.rmi.RemoteException;
  public WsplsqlRowtypeSqx92118x3x2User[] listmarcas() throws java.rmi.RemoteException;
  public WsplsqlRowtypeSqx92118x7x2User[] listproylistaprecios() throws java.rmi.RemoteException;
  public WsplsqlRowtypeSqx92118x6x2User[] listtipocambios() throws java.rmi.RemoteException;
  public WsplsqlRowtypeSqx92118x2x2User[] listunidmedidas() throws java.rmi.RemoteException;
}
