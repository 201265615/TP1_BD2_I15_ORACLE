package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public class WsplsqlRowtypeSqx92118x7x2Base implements ORAData, ORADataFactory
{
 public static final String _SQL_NAME = "WSPLSQL_ROWTYPE_SQX92118X7X2";
  public static final int _SQL_TYPECODE = OracleTypes.STRUCT;

 protected MutableStruct _struct;

 protected static int[] _sqlType =  { 12,2,2,2,2,2 };
 protected static ORADataFactory[] _factory = new ORADataFactory[6];
 protected static final WsplsqlRowtypeSqx92118x7x2Base _WsplsqlRowtypeSqx92118x7x2BaseFactory = new WsplsqlRowtypeSqx92118x7x2Base();

 public static ORADataFactory getORADataFactory()
  { return _WsplsqlRowtypeSqx92118x7x2BaseFactory; }
 /* constructors */
 protected void _init_struct(boolean init)
 { if (init) _struct = new MutableStruct(new Object[6], _sqlType, _factory); }
 public WsplsqlRowtypeSqx92118x7x2Base()
 { _init_struct(true); }
 public WsplsqlRowtypeSqx92118x7x2Base(String codarticulo, java.math.BigDecimal codlistaprecios, java.math.BigDecimal mes, java.math.BigDecimal anio, java.math.BigDecimal tipocambioproyect, java.math.BigDecimal preciomercdolaresproyect) throws SQLException
 { _init_struct(true);
 _setCodarticulo(codarticulo);
 _setCodlistaprecios(codlistaprecios);
 _setMes(mes);
 _setAnio(anio);
 _setTipocambioproyect(tipocambioproyect);
 _setPreciomercdolaresproyect(preciomercdolaresproyect);
  }

 /* ORAData interface */
 public Datum toDatum(Connection c) throws SQLException
  {
 _userSetterHelper();
    return _struct.toDatum(c, _SQL_NAME);
 }


 /* ORADataFactory interface */
 public ORAData create(Datum d, int sqlType) throws SQLException
 { return create(null, d, sqlType); }
 protected ORAData create(WsplsqlRowtypeSqx92118x7x2Base o, Datum d, int sqlType) throws SQLException
  {
 if (d == null) return null; 
    if (o == null) o = new WsplsqlRowtypeSqx92118x7x2User();
 o._struct = new MutableStruct((STRUCT) d, _sqlType, _factory);
    return o;
  }
 /* accessor methods */
 protected String _getCodarticulo() throws SQLException
 { return (String) _struct.getAttribute(0); }

 protected void _setCodarticulo(String codarticulo) throws SQLException
  { _struct.setAttribute(0, codarticulo); }


 protected java.math.BigDecimal _getCodlistaprecios() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(1); }

 protected void _setCodlistaprecios(java.math.BigDecimal codlistaprecios) throws SQLException
  { _struct.setAttribute(1, codlistaprecios); }


 protected java.math.BigDecimal _getMes() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(2); }

 protected void _setMes(java.math.BigDecimal mes) throws SQLException
  { _struct.setAttribute(2, mes); }


 protected java.math.BigDecimal _getAnio() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(3); }

 protected void _setAnio(java.math.BigDecimal anio) throws SQLException
  { _struct.setAttribute(3, anio); }


 protected java.math.BigDecimal _getTipocambioproyect() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(4); }

 protected void _setTipocambioproyect(java.math.BigDecimal tipocambioproyect) throws SQLException
  { _struct.setAttribute(4, tipocambioproyect); }


 protected java.math.BigDecimal _getPreciomercdolaresproyect() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(5); }

 protected void _setPreciomercdolaresproyect(java.math.BigDecimal preciomercdolaresproyect) throws SQLException
  { _struct.setAttribute(5, preciomercdolaresproyect); }

;
  // Some setter action is delayed until toDatum() 
  // where the connection is available 
  void _userSetterHelper() throws java.sql.SQLException {} 
}
