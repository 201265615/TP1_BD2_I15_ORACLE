package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public class WsplsqlRowtypeSqx92118x1x2Base implements ORAData, ORADataFactory
{
 public static final String _SQL_NAME = "WSPLSQL_ROWTYPE_SQX92118X1X2";
  public static final int _SQL_TYPECODE = OracleTypes.STRUCT;

 protected MutableStruct _struct;

 protected static int[] _sqlType =  { 12,12,2,2,12,91,2,2,12,2,2,2,2,91 };
 protected static ORADataFactory[] _factory = new ORADataFactory[14];
 protected static final WsplsqlRowtypeSqx92118x1x2Base _WsplsqlRowtypeSqx92118x1x2BaseFactory = new WsplsqlRowtypeSqx92118x1x2Base();

 public static ORADataFactory getORADataFactory()
  { return _WsplsqlRowtypeSqx92118x1x2BaseFactory; }
 /* constructors */
 protected void _init_struct(boolean init)
 { if (init) _struct = new MutableStruct(new Object[14], _sqlType, _factory); }
 public WsplsqlRowtypeSqx92118x1x2Base()
 { _init_struct(true); }
 public WsplsqlRowtypeSqx92118x1x2Base(String codigo, String descripcion, java.math.BigDecimal undmedida, java.math.BigDecimal codmarca, String modelo, java.sql.Timestamp fecregistro, java.math.BigDecimal codfamilia, java.math.BigDecimal codestarticulo, String coduserregistro, java.math.BigDecimal cantidad, java.math.BigDecimal cantmaxima, java.math.BigDecimal cantminima, java.math.BigDecimal preciomercdolares, java.sql.Timestamp fechaactprecio) throws SQLException
 { _init_struct(true);
 _setCodigo(codigo);
 _setDescripcion(descripcion);
 _setUndmedida(undmedida);
 _setCodmarca(codmarca);
 _setModelo(modelo);
 _setFecregistro(fecregistro);
 _setCodfamilia(codfamilia);
 _setCodestarticulo(codestarticulo);
 _setCoduserregistro(coduserregistro);
 _setCantidad(cantidad);
 _setCantmaxima(cantmaxima);
 _setCantminima(cantminima);
 _setPreciomercdolares(preciomercdolares);
 _setFechaactprecio(fechaactprecio);
  }

 /* ORAData interface */
 public Datum toDatum(Connection c) throws SQLException
  {
 _userSetterHelper();
    return _struct.toDatum(c, _SQL_NAME);
 }


 /* ORADataFactory interface */
 public ORAData create(Datum d, int sqlType) throws SQLException
 { return create(null, d, sqlType); }
 protected ORAData create(WsplsqlRowtypeSqx92118x1x2Base o, Datum d, int sqlType) throws SQLException
  {
 if (d == null) return null; 
    if (o == null) o = new WsplsqlRowtypeSqx92118x1x2User();
 o._struct = new MutableStruct((STRUCT) d, _sqlType, _factory);
    return o;
  }
 /* accessor methods */
 protected String _getCodigo() throws SQLException
 { return (String) _struct.getAttribute(0); }

 protected void _setCodigo(String codigo) throws SQLException
  { _struct.setAttribute(0, codigo); }


 protected String _getDescripcion() throws SQLException
 { return (String) _struct.getAttribute(1); }

 protected void _setDescripcion(String descripcion) throws SQLException
  { _struct.setAttribute(1, descripcion); }


 protected java.math.BigDecimal _getUndmedida() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(2); }

 protected void _setUndmedida(java.math.BigDecimal undmedida) throws SQLException
  { _struct.setAttribute(2, undmedida); }


 protected java.math.BigDecimal _getCodmarca() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(3); }

 protected void _setCodmarca(java.math.BigDecimal codmarca) throws SQLException
  { _struct.setAttribute(3, codmarca); }


 protected String _getModelo() throws SQLException
 { return (String) _struct.getAttribute(4); }

 protected void _setModelo(String modelo) throws SQLException
  { _struct.setAttribute(4, modelo); }


 protected java.sql.Timestamp _getFecregistro() throws SQLException
 { return (java.sql.Timestamp) _struct.getAttribute(5); }

 protected void _setFecregistro(java.sql.Timestamp fecregistro) throws SQLException
  { _struct.setAttribute(5, fecregistro); }


 protected java.math.BigDecimal _getCodfamilia() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(6); }

 protected void _setCodfamilia(java.math.BigDecimal codfamilia) throws SQLException
  { _struct.setAttribute(6, codfamilia); }


 protected java.math.BigDecimal _getCodestarticulo() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(7); }

 protected void _setCodestarticulo(java.math.BigDecimal codestarticulo) throws SQLException
  { _struct.setAttribute(7, codestarticulo); }


 protected String _getCoduserregistro() throws SQLException
 { return (String) _struct.getAttribute(8); }

 protected void _setCoduserregistro(String coduserregistro) throws SQLException
  { _struct.setAttribute(8, coduserregistro); }


 protected java.math.BigDecimal _getCantidad() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(9); }

 protected void _setCantidad(java.math.BigDecimal cantidad) throws SQLException
  { _struct.setAttribute(9, cantidad); }


 protected java.math.BigDecimal _getCantmaxima() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(10); }

 protected void _setCantmaxima(java.math.BigDecimal cantmaxima) throws SQLException
  { _struct.setAttribute(10, cantmaxima); }


 protected java.math.BigDecimal _getCantminima() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(11); }

 protected void _setCantminima(java.math.BigDecimal cantminima) throws SQLException
  { _struct.setAttribute(11, cantminima); }


 protected java.math.BigDecimal _getPreciomercdolares() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(12); }

 protected void _setPreciomercdolares(java.math.BigDecimal preciomercdolares) throws SQLException
  { _struct.setAttribute(12, preciomercdolares); }


 protected java.sql.Timestamp _getFechaactprecio() throws SQLException
 { return (java.sql.Timestamp) _struct.getAttribute(13); }

 protected void _setFechaactprecio(java.sql.Timestamp fechaactprecio) throws SQLException
  { _struct.setAttribute(13, fechaactprecio); }

;
  // Some setter action is delayed until toDatum() 
  // where the connection is available 
  void _userSetterHelper() throws java.sql.SQLException {} 
}
