package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.REF;
import oracle.sql.STRUCT;

public class WsplsqlRowtypeSqx92118x6x2UserRef implements ORAData, ORADataFactory
{
 public static final String _SQL_BASETYPE = "WSPLSQL_ROWTYPE_SQX92118X6X2";
  public static final int _SQL_TYPECODE = OracleTypes.REF;

 REF _ref;

private static final WsplsqlRowtypeSqx92118x6x2UserRef _WsplsqlRowtypeSqx92118x6x2UserRefFactory = new WsplsqlRowtypeSqx92118x6x2UserRef();

 public static ORADataFactory getORADataFactory()
  { return _WsplsqlRowtypeSqx92118x6x2UserRefFactory; }
 /* constructor */
 public WsplsqlRowtypeSqx92118x6x2UserRef()
 {
 }

 /* ORAData interface */
 public Datum toDatum(Connection c) throws SQLException
  {
    return _ref;
 }

  /* ORADataFactory interface */
  public ORAData create(Datum d, int sqlType) throws SQLException
  {
    if (d == null) return null; 
    WsplsqlRowtypeSqx92118x6x2UserRef r = new WsplsqlRowtypeSqx92118x6x2UserRef();
 r._ref = (REF) d;
    return r;
  }

 public static WsplsqlRowtypeSqx92118x6x2UserRef cast(ORAData o) throws SQLException
 {
 if (o == null) return null;
 try { return (WsplsqlRowtypeSqx92118x6x2UserRef) getORADataFactory().create(o.toDatum(null), OracleTypes.REF); }
 catch (Exception exn)
 { throw new SQLException("Unable to convert "+o.getClass().getName()+" to WsplsqlRowtypeSqx92118x6x2UserRef: "+exn.toString()); }
  }

 public WsplsqlRowtypeSqx92118x6x2User getValue() throws SQLException
 {
 return (WsplsqlRowtypeSqx92118x6x2User) WsplsqlRowtypeSqx92118x6x2User.getORADataFactory().create(
 _ref.getSTRUCT(), OracleTypes.REF);
 }

 public void setValue(WsplsqlRowtypeSqx92118x6x2User c) throws SQLException
 {
 _ref.setValue((STRUCT) c.toDatum(_ref.getJavaSqlConnection()));
  }
}
