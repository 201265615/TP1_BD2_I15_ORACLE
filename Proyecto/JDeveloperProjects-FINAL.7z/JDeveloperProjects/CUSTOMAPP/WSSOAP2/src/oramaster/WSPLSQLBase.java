package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import java.io.*;

public class WSPLSQLBase
{

  /* connection management */
  protected javax.sql.DataSource __dataSource = null;
 public void _setDataSource(javax.sql.DataSource dataSource) throws SQLException
  { __dataSource = dataSource; }
 public void _setDataSourceLocation(String dataSourceLocation) throws SQLException {
 javax.sql.DataSource dataSource;
 try {
 Class cls = Class.forName("javax.naming.InitialContext");
 Object ctx = cls.newInstance();
 java.lang.reflect.Method meth = cls.getMethod("lookup", new Class[]{String.class});
 dataSource = (javax.sql.DataSource) meth.invoke(ctx, new Object[]{"java:comp/env/" + dataSourceLocation});
 _setDataSource(dataSource);
 } catch (Exception e) {
 throw new java.sql.SQLException("Error initializing DataSource at " + dataSourceLocation + ": " + e.getMessage());
 }
  }

 /* constructors */
 public WSPLSQLBase() throws SQLException
  {  try {
 javax.naming.InitialContext __initCtx = new javax.naming.InitialContext();
 __dataSource = (javax.sql.DataSource) __initCtx.lookup("java:comp/env/jdbc/oramasterDS");
 } catch (Exception __jndie) { 
 throw new java.sql.SQLException("Error looking up <java:comp/env/jdbc/oramasterDS>: " + __jndie.getMessage()); 
   }
 }
 public WSPLSQLBase(javax.sql.DataSource ds) throws SQLException { __dataSource = ds; }

  protected WsplsqlArrarticulos _listarticulos (Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
 WsplsqlArrarticulos __jPt_result=null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN :1 := WSPLSQL_plsql_wrapper.PL_TO_SQL0(\"FINALPKGPROGRA1\".LISTARTICULOS()); END;");
    __sJT_st.registerOutParameter(1, 2003, "WSPLSQL_ARRARTICULOS");
    __sJT_st.executeUpdate();
    __jPt_result = (WsplsqlArrarticulos) __sJT_st.getORAData(1, WsplsqlArrarticulos.getORADataFactory());
    try { __sJT_st.close(); } catch (Exception e) {}
    return __jPt_result;
  }

  protected WsplsqlArrcomponentes _listcomponentes (Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
 WsplsqlArrcomponentes __jPt_result=null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN :1 := WSPLSQL_plsql_wrapper.PL_TO_SQL1(\"FINALPKGPROGRA1\".LISTCOMPONENTES()); END;");
    __sJT_st.registerOutParameter(1, 2003, "WSPLSQL_ARRCOMPONENTES");
    __sJT_st.executeUpdate();
    __jPt_result = (WsplsqlArrcomponentes) __sJT_st.getORAData(1, WsplsqlArrcomponentes.getORADataFactory());
    try { __sJT_st.close(); } catch (Exception e) {}
    return __jPt_result;
  }

  protected WsplsqlArrfamilias _listfamilias (Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
 WsplsqlArrfamilias __jPt_result=null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN :1 := WSPLSQL_plsql_wrapper.PL_TO_SQL2(\"FINALPKGPROGRA1\".LISTFAMILIAS()); END;");
    __sJT_st.registerOutParameter(1, 2003, "WSPLSQL_ARRFAMILIAS");
    __sJT_st.executeUpdate();
    __jPt_result = (WsplsqlArrfamilias) __sJT_st.getORAData(1, WsplsqlArrfamilias.getORADataFactory());
    try { __sJT_st.close(); } catch (Exception e) {}
    return __jPt_result;
  }

  protected WsplsqlArrmarcas _listmarcas (Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
 WsplsqlArrmarcas __jPt_result=null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN :1 := WSPLSQL_plsql_wrapper.PL_TO_SQL3(\"FINALPKGPROGRA1\".LISTMARCAS()); END;");
    __sJT_st.registerOutParameter(1, 2003, "WSPLSQL_ARRMARCAS");
    __sJT_st.executeUpdate();
    __jPt_result = (WsplsqlArrmarcas) __sJT_st.getORAData(1, WsplsqlArrmarcas.getORADataFactory());
    try { __sJT_st.close(); } catch (Exception e) {}
    return __jPt_result;
  }

  protected WsplsqlArrproylistaprecios _listproylistaprecios (Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
 WsplsqlArrproylistaprecios __jPt_result=null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN :1 := WSPLSQL_plsql_wrapper.PL_TO_SQL4(\"FINALPKGPROGRA1\".LISTPROYLISTAPRECIOS()); END;");
    __sJT_st.registerOutParameter(1, 2003, "WSPLSQL_ARRPROYLISTAPRECIOS");
    __sJT_st.executeUpdate();
    __jPt_result = (WsplsqlArrproylistaprecios) __sJT_st.getORAData(1, WsplsqlArrproylistaprecios.getORADataFactory());
    try { __sJT_st.close(); } catch (Exception e) {}
    return __jPt_result;
  }

  protected WsplsqlArrtipocambios _listtipocambios (Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
 WsplsqlArrtipocambios __jPt_result=null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN :1 := WSPLSQL_plsql_wrapper.PL_TO_SQL5(\"FINALPKGPROGRA1\".LISTTIPOCAMBIOS()); END;");
    __sJT_st.registerOutParameter(1, 2003, "WSPLSQL_ARRTIPOCAMBIOS");
    __sJT_st.executeUpdate();
    __jPt_result = (WsplsqlArrtipocambios) __sJT_st.getORAData(1, WsplsqlArrtipocambios.getORADataFactory());
    try { __sJT_st.close(); } catch (Exception e) {}
    return __jPt_result;
  }

  protected WsplsqlArrunidmedidas _listunidmedidas (Connection __onnScopeMethod)
  throws java.sql.SQLException
  {
    java.sql.Connection __sJT_cc = null;
 WsplsqlArrunidmedidas __jPt_result=null;
    oracle.jdbc.OracleCallableStatement __sJT_st=null;
    __sJT_cc = __onnScopeMethod;
 __sJT_st = (oracle.jdbc.OracleCallableStatement) __sJT_cc.prepareCall("BEGIN :1 := WSPLSQL_plsql_wrapper.PL_TO_SQL6(\"FINALPKGPROGRA1\".LISTUNIDMEDIDAS()); END;");
    __sJT_st.registerOutParameter(1, 2003, "WSPLSQL_ARRUNIDMEDIDAS");
    __sJT_st.executeUpdate();
    __jPt_result = (WsplsqlArrunidmedidas) __sJT_st.getORAData(1, WsplsqlArrunidmedidas.getORADataFactory());
    try { __sJT_st.close(); } catch (Exception e) {}
    return __jPt_result;
  }
}
