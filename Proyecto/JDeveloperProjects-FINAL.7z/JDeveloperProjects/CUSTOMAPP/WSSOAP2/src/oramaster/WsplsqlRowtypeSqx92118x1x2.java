package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public interface WsplsqlRowtypeSqx92118x1x2 {

 public void setCodigo(String codigo) throws SQLException;
 public String getCodigo() throws SQLException;

 public void setDescripcion(String descripcion) throws SQLException;
 public String getDescripcion() throws SQLException;

 public void setUndmedida(java.math.BigDecimal undmedida) throws SQLException;
 public java.math.BigDecimal getUndmedida() throws SQLException;

 public void setCodmarca(java.math.BigDecimal codmarca) throws SQLException;
 public java.math.BigDecimal getCodmarca() throws SQLException;

 public void setModelo(String modelo) throws SQLException;
 public String getModelo() throws SQLException;

 public void setFecregistro(java.util.Calendar fecregistro) throws SQLException;
 public java.util.Calendar getFecregistro() throws SQLException;

 public void setCodfamilia(java.math.BigDecimal codfamilia) throws SQLException;
 public java.math.BigDecimal getCodfamilia() throws SQLException;

 public void setCodestarticulo(java.math.BigDecimal codestarticulo) throws SQLException;
 public java.math.BigDecimal getCodestarticulo() throws SQLException;

 public void setCoduserregistro(String coduserregistro) throws SQLException;
 public String getCoduserregistro() throws SQLException;

 public void setCantidad(java.math.BigDecimal cantidad) throws SQLException;
 public java.math.BigDecimal getCantidad() throws SQLException;

 public void setCantmaxima(java.math.BigDecimal cantmaxima) throws SQLException;
 public java.math.BigDecimal getCantmaxima() throws SQLException;

 public void setCantminima(java.math.BigDecimal cantminima) throws SQLException;
 public java.math.BigDecimal getCantminima() throws SQLException;

 public void setPreciomercdolares(java.math.BigDecimal preciomercdolares) throws SQLException;
 public java.math.BigDecimal getPreciomercdolares() throws SQLException;

 public void setFechaactprecio(java.util.Calendar fechaactprecio) throws SQLException;
 public java.util.Calendar getFechaactprecio() throws SQLException;


}
