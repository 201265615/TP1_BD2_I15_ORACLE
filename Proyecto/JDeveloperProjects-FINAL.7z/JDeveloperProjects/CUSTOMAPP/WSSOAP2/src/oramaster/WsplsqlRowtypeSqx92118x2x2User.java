package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public class WsplsqlRowtypeSqx92118x2x2User extends WsplsqlRowtypeSqx92118x2x2Base implements ORAData, ORADataFactory, WsplsqlRowtypeSqx92118x2x2
{
 private static final WsplsqlRowtypeSqx92118x2x2User _WsplsqlRowtypeSqx92118x2x2UserFactory = new WsplsqlRowtypeSqx92118x2x2User();
 public static ORADataFactory getORADataFactory()
   { return _WsplsqlRowtypeSqx92118x2x2UserFactory; }

   public WsplsqlRowtypeSqx92118x2x2User() { super(); }
 public WsplsqlRowtypeSqx92118x2x2User(java.math.BigDecimal codigo, String descripcion) throws SQLException
 {
 _setCodigo(codigo);
 _setDescripcion(descripcion);
  }
 /* ORAData interface */
 public ORAData create(Datum d, int sqlType) throws SQLException
 { return create(new WsplsqlRowtypeSqx92118x2x2User(), d, sqlType); }

  /* superclass accessors */

 public void setCodigo(java.math.BigDecimal codigo) throws SQLException { super._setCodigo(codigo); }
 public java.math.BigDecimal getCodigo() throws SQLException { return super._getCodigo(); }


 public void setDescripcion(String descripcion) throws SQLException { super._setDescripcion(descripcion); }
 public String getDescripcion() throws SQLException { return super._getDescripcion(); }



}
