@javax.xml.bind.annotation.XmlSchema(namespace = "http://oramaster/WSPLSQLMS.wsdl/types/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package oramaster.wsplsqlms_wsdl.types;
