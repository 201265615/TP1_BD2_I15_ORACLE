@javax.xml.bind.annotation.XmlSchema(namespace = "http://oramaster/WSPLSQL.wsdl/types/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package oramaster.wsplsql_wsdl.types;
