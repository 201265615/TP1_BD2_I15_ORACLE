
package oramaster.wsplsql_wsdl.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WsplsqlRowtypeSqx92118x5x2User complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WsplsqlRowtypeSqx92118x5x2User">
 *   &lt;complexContent>
 *     &lt;extension base="{http://oramaster/WSPLSQL.wsdl/types/}WsplsqlRowtypeSqx92118x5x2Base">
 *       &lt;sequence>
 *         &lt;element name="codarticulo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codcomponente" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WsplsqlRowtypeSqx92118x5x2User", propOrder = {
    "codarticulo",
    "codcomponente"
})
public class WsplsqlRowtypeSqx92118X5X2User
    extends WsplsqlRowtypeSqx92118X5X2Base
{

    @XmlElement(required = true, nillable = true)
    protected String codarticulo;
    @XmlElement(required = true, nillable = true)
    protected String codcomponente;

    /**
     * Gets the value of the codarticulo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodarticulo() {
        return codarticulo;
    }

    /**
     * Sets the value of the codarticulo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodarticulo(String value) {
        this.codarticulo = value;
    }

    /**
     * Gets the value of the codcomponente property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodcomponente() {
        return codcomponente;
    }

    /**
     * Sets the value of the codcomponente property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodcomponente(String value) {
        this.codcomponente = value;
    }

}
