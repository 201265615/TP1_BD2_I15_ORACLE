
package oramaster.wsplsql_wsdl.types;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WsplsqlRowtypeSqx92118x1x2UserArray complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WsplsqlRowtypeSqx92118x1x2UserArray">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="WsplsqlRowtypeSqx92118x1x2User" type="{http://oramaster/WSPLSQL.wsdl/types/}WsplsqlRowtypeSqx92118x1x2User" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WsplsqlRowtypeSqx92118x1x2UserArray", propOrder = {
    "wsplsqlRowtypeSqx92118X1X2User"
})
public class WsplsqlRowtypeSqx92118X1X2UserArray {

    @XmlElement(name = "WsplsqlRowtypeSqx92118x1x2User", nillable = true)
    protected List<WsplsqlRowtypeSqx92118X1X2User> wsplsqlRowtypeSqx92118X1X2User;

    /**
     * Gets the value of the wsplsqlRowtypeSqx92118X1X2User property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wsplsqlRowtypeSqx92118X1X2User property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWsplsqlRowtypeSqx92118X1X2User().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WsplsqlRowtypeSqx92118X1X2User }
     * 
     * 
     */
    public List<WsplsqlRowtypeSqx92118X1X2User> getWsplsqlRowtypeSqx92118X1X2User() {
        if (wsplsqlRowtypeSqx92118X1X2User == null) {
            wsplsqlRowtypeSqx92118X1X2User = new ArrayList<WsplsqlRowtypeSqx92118X1X2User>();
        }
        return this.wsplsqlRowtypeSqx92118X1X2User;
    }

}
