
package oramaster.wsplsql_wsdl.types;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WsplsqlRowtypeSqx92118x7x2User complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WsplsqlRowtypeSqx92118x7x2User">
 *   &lt;complexContent>
 *     &lt;extension base="{http://oramaster/WSPLSQL.wsdl/types/}WsplsqlRowtypeSqx92118x7x2Base">
 *       &lt;sequence>
 *         &lt;element name="anio" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="preciomercdolaresproyect" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="codlistaprecios" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="mes" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="tipocambioproyect" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="codarticulo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WsplsqlRowtypeSqx92118x7x2User", propOrder = {
    "anio",
    "preciomercdolaresproyect",
    "codlistaprecios",
    "mes",
    "tipocambioproyect",
    "codarticulo"
})
public class WsplsqlRowtypeSqx92118X7X2User
    extends WsplsqlRowtypeSqx92118X7X2Base
{

    @XmlElement(required = true, nillable = true)
    protected BigDecimal anio;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal preciomercdolaresproyect;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal codlistaprecios;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal mes;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal tipocambioproyect;
    @XmlElement(required = true, nillable = true)
    protected String codarticulo;

    /**
     * Gets the value of the anio property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAnio() {
        return anio;
    }

    /**
     * Sets the value of the anio property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAnio(BigDecimal value) {
        this.anio = value;
    }

    /**
     * Gets the value of the preciomercdolaresproyect property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPreciomercdolaresproyect() {
        return preciomercdolaresproyect;
    }

    /**
     * Sets the value of the preciomercdolaresproyect property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPreciomercdolaresproyect(BigDecimal value) {
        this.preciomercdolaresproyect = value;
    }

    /**
     * Gets the value of the codlistaprecios property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCodlistaprecios() {
        return codlistaprecios;
    }

    /**
     * Sets the value of the codlistaprecios property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCodlistaprecios(BigDecimal value) {
        this.codlistaprecios = value;
    }

    /**
     * Gets the value of the mes property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMes() {
        return mes;
    }

    /**
     * Sets the value of the mes property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMes(BigDecimal value) {
        this.mes = value;
    }

    /**
     * Gets the value of the tipocambioproyect property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTipocambioproyect() {
        return tipocambioproyect;
    }

    /**
     * Sets the value of the tipocambioproyect property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTipocambioproyect(BigDecimal value) {
        this.tipocambioproyect = value;
    }

    /**
     * Gets the value of the codarticulo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodarticulo() {
        return codarticulo;
    }

    /**
     * Sets the value of the codarticulo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodarticulo(String value) {
        this.codarticulo = value;
    }

}
