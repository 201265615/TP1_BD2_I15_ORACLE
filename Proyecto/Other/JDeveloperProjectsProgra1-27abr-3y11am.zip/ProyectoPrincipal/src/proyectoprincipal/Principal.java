package proyectoprincipal;


//Import del package de listas (R)
import clienteLWS2.WSPLSQL;
import clienteLWS2.WSPLSQL_Service;
import clienteLWS2.WSPLSQLPortClient;
import oramaster.wsplsql_wsdl.types.*;

//Import del package de (CUD)
import clienteLWS3.WSPLSQL3;
import clienteLWS3.WSPLSQL3_Service;
import clienteLWS3.WSPLSQL3PortClient;


import javax.swing.JScrollPane;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import java.math.BigDecimal;

import java.rmi.RemoteException;

import java.util.*;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import javax.swing.JTable;

import javax.swing.JTextArea;
import javax.swing.JTextField;

import oracle.jdeveloper.layout.PaneLayout;

import oracle.jdeveloper.layout.XYLayout;

import proyectoprincipal.CrearComponente;

import javax.swing.JTabbedPane;

import javax.swing.table.DefaultTableModel;


public class Principal extends JFrame {
    private JMenuBar menuBar = new JMenuBar();
    private JMenu menuFile = new JMenu();
    private JMenuItem menuFileExit = new JMenuItem();
    //Cambio de linea
    //private MyWSPortClient cliente = new MyWSPortClient();
    //private WSPLSQLPortClient cliente = new WSPLSQLPortClient();

    private JTabbedPane jTabbedPane1 = new JTabbedPane();
    private JPanel jPanel1 = new JPanel();
    private JPanel jPanel2 = new JPanel();
    private JPanel jPanel3 = new JPanel();
    private JPanel jPanel4 = new JPanel();
    private PaneLayout paneLayout1 = new PaneLayout();
    private GridLayout gridLayout1 = new GridLayout();
    private XYLayout xYLayout1 = new XYLayout();
    private XYLayout xYLayout2 = new XYLayout();
    private JPanel jPanel5 = new JPanel();
    private JPanel jPanel6 = new JPanel();
    private JTabbedPane jTabbedPane2 = new JTabbedPane();
    private JPanel jPanel7 = new JPanel();
    private JTable jTable1 = new JTable();
    private JTable jTable2 = new JTable();
    private JPanel jPanel8 = new JPanel();
    private JTabbedPane jTabbedPane3 = new JTabbedPane();
    private JTabbedPane jTabbedPane4 = new JTabbedPane();
    private JTabbedPane jTabbedPane5 = new JTabbedPane();
    private JTable jTable3 = new JTable();
    private JTextField jTextField3 = new JTextField();
    private JButton jButton5 = new JButton();
    private JTextField jTextField7 = new JTextField();
    private JTextField jTextField6 = new JTextField();
    private JTextField jTextField5 = new JTextField();
    private JTextField jTextField4 = new JTextField();
    private JComboBox jComboBox4 = new JComboBox();
    private JComboBox jComboBox3 = new JComboBox();
    private JComboBox jComboBox2 = new JComboBox();
    private JComboBox jComboBox1 = new JComboBox();
    private JTextField jTextField2 = new JTextField();
    private JTextField jTextField1 = new JTextField();
    private JLabel jLabel12 = new JLabel();
    private JLabel jLabel11 = new JLabel();
    private JLabel jLabel10 = new JLabel();
    private JLabel jLabel9 = new JLabel();
    private JLabel jLabel8 = new JLabel();
    private JLabel jLabel7 = new JLabel();
    private JLabel jLabel6 = new JLabel();
    private JLabel jLabel5 = new JLabel();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel1 = new JLabel();
    private JButton jButton6 = new JButton();
    private JButton jButton8 = new JButton();
    private JLabel jLabel25 = new JLabel();
    private JLabel jLabel116 = new JLabel();
    private JTextField jTextField16 = new JTextField();
    private JTextField jTextField20 = new JTextField();
    private JButton jButton9 = new JButton();
    private JComboBox jComboBox14 = new JComboBox();
    private JLabel jLabel28 = new JLabel();
    private JLabel jLabel29 = new JLabel();
    private JTextField jTextField22 = new JTextField();
    private JButton jButton10 = new JButton();
    private JTextField jTextField23 = new JTextField();
    private JTextField jTextField110 = new JTextField();
    private JTextField jTextField111 = new JTextField();
    private JTextField jTextField112 = new JTextField();
    private JComboBox jComboBox16 = new JComboBox();
    private JComboBox jComboBox17 = new JComboBox();
    private JComboBox jComboBox18 = new JComboBox();
    private JComboBox jComboBox19 = new JComboBox();
    private JTextField jTextField113 = new JTextField();
    private JLabel jLabel117 = new JLabel();
    private JLabel jLabel118 = new JLabel();
    private JLabel jLabel119 = new JLabel();
    private JLabel jLabel1110 = new JLabel();
    private JLabel jLabel1111 = new JLabel();
    private JLabel jLabel1112 = new JLabel();
    private JLabel jLabel1113 = new JLabel();
    private JLabel jLabel210 = new JLabel();
    private JLabel jLabel211 = new JLabel();
    private JLabel jLabel212 = new JLabel();
    private JTextField jTextField114 = new JTextField();
    private JButton jButton11 = new JButton();
    private JButton jButton13 = new JButton();
    private JButton jButton14;
    private JTable jTable4 = new JTable();
    private JTextArea jTextArea1 = new JTextArea();
    private JButton jButton1 = new JButton();
    private JButton jButton2 = new JButton();
    private JTextArea jTextArea2 = new JTextArea();
    private JScrollPane jScrollPane1 = new JScrollPane();
    private JScrollPane jScrollPane2 = new JScrollPane();
    //Para conectarse con la clase que consume el WS
    
    
    
    /* 
     * ===================================================================================
     * Variables utlizadas para el control de lista de combobox
     * ===================================================================================
     */
    public List<ComboItem> lstArticulos = new ArrayList();
    public List<ComboItem> lstUndMedida = new ArrayList();
    public List<ComboItem> lstFamilias = new ArrayList();
    public List<ComboItem> lstMarcas = new ArrayList();
    public List<ComboItem> lstEstadoArticulos = new ArrayList();
    public List<ComboItem> lstComponentes = new ArrayList();
    private JButton jButton17 = new JButton();
    private JButton jButton16 = new JButton();
    private JComboBox jComboBox5 = new JComboBox();
    private JComboBox jComboBox6 = new JComboBox();
    private JTextField jTextField17 = new JTextField();
    private JTextField jTextField18 = new JTextField();
    private JLabel jLabel214 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel213 = new JLabel();
    private JLabel jLabel13 = new JLabel();


    /*
     * ===================================================================================
     * ===================================================================================
     */
    

    public Principal() {
        try {
            jbInit();
            //Carga todo
            this.FullRefresh();
            this.ConfiguraComponentes();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//End Constructor

    private void jbInit() throws Exception {
        this.setJMenuBar( menuBar );
        this.getContentPane().setLayout( null );
        this.setSize(new Dimension(751, 548));
        this.setTitle( "Principal" );
        menuFile.setText( "Archivo" );
        menuFileExit.setText( "Salir" );
        menuFileExit.addActionListener( new ActionListener() { public void actionPerformed( ActionEvent ae ) { fileExit_ActionPerformed( ae ); } } );
        jTabbedPane1.setBounds(new Rectangle(5, 5, 730, 460));
        jPanel2.setLayout(null);
        jPanel3.setLayout(null);
        jPanel4.setLayout(null);
        jPanel6.setLayout(null);
        jTabbedPane2.setBounds(new Rectangle(10, 40, 705, 210));
        jPanel7.setLayout(null);
        jPanel8.setLayout(null);
        jTabbedPane3.setBounds(new Rectangle(10, 15, 705, 125));
        jTabbedPane5.setBounds(new Rectangle(10, 15, 705, 125));
        jTextField3.setBounds(new Rectangle(260, 45, 110, 20));
        jTextField3.setBounds(new Rectangle(260, 45, 110, 20));
        jButton5.setText("Crear Articulo");
        jButton5.setBounds(new Rectangle(195, 155, 110, 20));
        jTextField7.setBounds(new Rectangle(490, 105, 80, 20));
        jTextField6.setBounds(new Rectangle(490, 75, 80, 20));
        jTextField5.setBounds(new Rectangle(490, 45, 80, 20));
        jTextField4.setBounds(new Rectangle(490, 15, 80, 20));
        jComboBox4.setBounds(new Rectangle(260, 105, 110, 20));
        jComboBox3.setBounds(new Rectangle(260, 75, 110, 20));
        jComboBox2.setBounds(new Rectangle(95, 105, 105, 20));
        jComboBox1.setBounds(new Rectangle(95, 75, 105, 20));
        jTextField2.setBounds(new Rectangle(95, 15, 275, 20));
        jTextField1.setBounds(new Rectangle(95, 45, 105, 20));
        jLabel12.setText("Precio en Dolares:");
        jLabel12.setBounds(new Rectangle(400, 110, 90, 15));
        jLabel11.setText("Cantidad Minima:");
        jLabel11.setBounds(new Rectangle(405, 80, 105, 15));
        jLabel10.setText("Cantidad Maxima:");
        jLabel10.setBounds(new Rectangle(400, 50, 115, 15));
        jLabel9.setText("Cantidad:");
        jLabel9.setBounds(new Rectangle(440, 20, 60, 15));
        jLabel8.setText("Estado:");
        jLabel8.setBounds(new Rectangle(220, 110, 45, 15));
        jLabel7.setText("Familia:");
        jLabel7.setBounds(new Rectangle(220, 80, 55, 15));
        jLabel6.setText("Modelo:");
        jLabel6.setBounds(new Rectangle(220, 50, 45, 15));
        jLabel5.setText("Marca:");
        jLabel5.setBounds(new Rectangle(60, 110, 34, 14));
        jLabel3.setText("Unidad de Medida:");
        jLabel3.setBounds(new Rectangle(5, 80, 100, 15));
        jLabel2.setText("Descripcion:");
        jLabel2.setBounds(new Rectangle(35, 20, 65, 15));
        jLabel1.setText("Codigo:");
        jLabel1.setBounds(new Rectangle(55, 50, 50, 15));
        jButton6.setText("Volver");
        jButton6.setBounds(new Rectangle(320, 155, 75, 21));
        jButton6.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton1_actionPerformed(e);
                }
            });
        jButton8.setText("Eliminar Articulo");
        jButton8.setBounds(new Rectangle(570, 125, 110, 20));
        jButton8.setActionCommand("Eliminar Articulo");
        jButton8.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton8_actionPerformed(e);
                }
            });
        jLabel25.setText("Descripcion:");
        jLabel25.setBounds(new Rectangle(30, 60, 60, 15));
        jLabel116.setText("Precio en Dolares:");
        jLabel116.setBounds(new Rectangle(25, 100, 90, 15));
        jTextField16.setBounds(new Rectangle(115, 20, 185, 20));
        jTextField16.setEditable(false);
        jTextField20.setBounds(new Rectangle(115, 95, 130, 20));
        jButton9.setText("Aplicar cambios");
        jButton9.setBounds(new Rectangle(570, 95, 110, 20));
        jButton9.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton9_actionPerformed(e);
                }
            });
        jComboBox14.setBounds(new Rectangle(95, 55, 455, 20));
        jLabel28.setText("Codigo del articulo:");
        jLabel28.setBounds(new Rectangle(15, 25, 100, 15));
        jLabel29.setText("Codigo del articulo:");
        jLabel29.setBounds(new Rectangle(15, 25, 100, 15));
        jTextField22.setBounds(new Rectangle(260, 45, 110, 20));
        jTextField22.setBounds(new Rectangle(260, 85, 110, 20));
        jButton10.setText("Agregar articulo");
        jButton10.setBounds(new Rectangle(570, 95, 120, 20));
        jButton10.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton10_actionPerformed(e);
                }
            });
        jTextField23.setBounds(new Rectangle(470, 145, 80, 20));
        jTextField110.setBounds(new Rectangle(470, 115, 80, 20));
        jTextField111.setBounds(new Rectangle(470, 85, 80, 20));
        jTextField112.setBounds(new Rectangle(95, 85, 105, 20));
        jComboBox16.setBounds(new Rectangle(260, 145, 110, 20));
        jComboBox17.setBounds(new Rectangle(260, 115, 110, 20));
        jComboBox18.setBounds(new Rectangle(95, 145, 105, 20));
        jComboBox19.setBounds(new Rectangle(95, 115, 105, 20));
        jTextField113.setBounds(new Rectangle(95, 55, 455, 20));
        jLabel117.setText("Precio en Dolares:");
        jLabel117.setBounds(new Rectangle(380, 150, 90, 15));
        jLabel118.setText("Cantidad Minima:");
        jLabel118.setBounds(new Rectangle(385, 120, 105, 15));
        jLabel119.setText("Cantidad Maxima:");
        jLabel119.setBounds(new Rectangle(380, 90, 115, 15));
        jLabel1110.setText("Cantidad:");
        jLabel1110.setBounds(new Rectangle(40, 90, 50, 15));
        jLabel1111.setText("Estado:");
        jLabel1111.setBounds(new Rectangle(220, 150, 45, 15));
        jLabel1112.setText("Familia:");
        jLabel1112.setBounds(new Rectangle(220, 120, 55, 15));
        jLabel1113.setText("Modelo:");
        jLabel1113.setBounds(new Rectangle(220, 90, 45, 15));
        jLabel210.setText("Marca:");
        jLabel210.setBounds(new Rectangle(60, 150, 35, 15));
        jLabel211.setText("Unidad de Medida:");
        jLabel211.setBounds(new Rectangle(5, 120, 100, 15));
        jLabel212.setText("Descripcion:");
        jLabel212.setBounds(new Rectangle(30, 60, 60, 15));
        jTextField114.setBounds(new Rectangle(115, 20, 215, 20));
        jButton11.setText("Refrescar");
        jButton11.setBounds(new Rectangle(10, 10, 100, 20));
        jButton11.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton11_actionPerformed(e);
                }
            });
        jButton13.setText("Refrescar");
        jButton13.setBounds(new Rectangle(10, 10, 100, 20));
        jTextArea1.setBounds(new Rectangle(15, 60, 695, 285));
        jButton1.setText("Refrescar");
        jButton1.setBounds(new Rectangle(15, 25, 135, 20));
        jButton2.setText("Refrescar");
        jButton2.setBounds(new Rectangle(15, 25, 135, 20));
        jTextArea2.setBounds(new Rectangle(15, 60, 695, 285));
        jScrollPane1.setBounds(new Rectangle(10, 255, 705, 175));
        jScrollPane2.setBounds(new Rectangle(10, 255, 705, 175));
        jButton17.setText("Agregar componente al contenedor");
        jButton17.setBounds(new Rectangle(135, 180, 225, 25));
        jButton17.setActionCommand("Agregar componente al contenedor");
        jButton17.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton1_actionPerformed(e);
                }
            });
        jButton16.setText("Eliminar Articulo contenedor");
        jButton16.setBounds(new Rectangle(370, 180, 205, 25));
        jButton16.setActionCommand("Eliminar Articulo");
        jButton16.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton16_actionPerformed(e);
                }
            });
        jComboBox5.setBounds(new Rectangle(325, 140, 345, 20));
        jComboBox6.setBounds(new Rectangle(325, 80, 345, 20));
        jTextField17.setBounds(new Rectangle(125, 80, 185, 20));
        jTextField17.setEditable(false);
        jTextField18.setBounds(new Rectangle(125, 140, 185, 20));
        jTextField18.setEditable(false);
        jLabel214.setText("Codigo del articulo:");
        jLabel214.setBounds(new Rectangle(25, 145, 100, 15));
        jLabel4.setText("Seleccione Nombre del Articulo que sera componente:");
        jLabel4.setBounds(new Rectangle(25, 115, 265, 15));
        jLabel213.setText("Codigo del articulo:");
        jLabel213.setBounds(new Rectangle(25, 85, 100, 15));
        jLabel13.setText("Seleccione Nombre del Articulo que sera contenedor:");
        jLabel13.setBounds(new Rectangle(25, 55, 265, 15));
        menuFile.add( menuFileExit );
        menuBar.add( menuFile );
        jPanel7.add(jTextField114, null);
        jPanel7.add(jLabel212, null);
        jPanel7.add(jLabel211, null);
        jPanel7.add(jLabel210, null);
        jPanel7.add(jLabel1113, null);
        jPanel7.add(jLabel1112, null);
        jPanel7.add(jLabel1111, null);
        jPanel7.add(jLabel1110, null);
        jPanel7.add(jLabel119, null);
        jPanel7.add(jLabel118, null);
        jPanel7.add(jLabel117, null);
        jPanel7.add(jTextField113, null);
        jPanel7.add(jComboBox19, null);
        jPanel7.add(jComboBox18, null);
        jPanel7.add(jComboBox17, null);
        jPanel7.add(jComboBox16, null);
        jPanel7.add(jTextField112, null);
        jPanel7.add(jTextField111, null);
        jPanel7.add(jTextField110, null);
        jPanel7.add(jTextField23, null);
        jPanel7.add(jButton10, null);
        jPanel7.add(jTextField22, null);
        jPanel7.add(jLabel29, null);
        jPanel8.add(jLabel28, null);
        jPanel8.add(jComboBox14, null);
        jPanel8.add(jButton9, null);
        jPanel8.add(jTextField20, null);
        jPanel8.add(jTextField16, null);
        jPanel8.add(jLabel116, null);
        jPanel8.add(jLabel25, null);
        jPanel8.add(jButton8, null);
        jTabbedPane2.addTab("Agregar", jPanel7);
        jTabbedPane2.addTab("Editar", jPanel8);
        jScrollPane1.getViewport().add(jTable2, null);
        jPanel2.add(jScrollPane1, null);
        jPanel2.add(jTabbedPane2, null);
        jPanel2.add(jButton11, null);
        jTabbedPane1.addTab("Articulos", jPanel2);
        jScrollPane2.getViewport().add(jTable3, null);
        jPanel3.add(jLabel13, null);
        jPanel3.add(jLabel213, null);
        jPanel3.add(jLabel4, null);
        jPanel3.add(jLabel214, null);
        jPanel3.add(jTextField18, null);
        jPanel3.add(jTextField17, null);
        jPanel3.add(jComboBox6, null);
        jPanel3.add(jComboBox5, null);
        jPanel3.add(jButton16, null);
        jPanel3.add(jButton17, null);
        jPanel3.add(jScrollPane2, null);
        jPanel3.add(jButton13, null);
        jTabbedPane1.addTab("Componentes", jPanel3);
        jPanel4.add(jButton1, null);
        jPanel4.add(jTextArea1, null);
        jTabbedPane1.addTab("Tipo Cambios", jPanel4);
        jPanel6.add(jTextArea2, null);
        jPanel6.add(jButton2, null);
        jTabbedPane1.addTab("Proyeccion Precio Articulos", jPanel6);
        this.getContentPane().add(jTabbedPane1, null);
    }

    void fileExit_ActionPerformed(ActionEvent e) {
        System.exit(0);
    }

    private void jButton1_actionPerformed(ActionEvent e) {
        this.insertarComponente();
        this.FullRefresh();
    }//End Method

    private void jButton2_actionPerformed(ActionEvent e) {
        VerEliminarComponentes nuevaVentana = new VerEliminarComponentes();
        nuevaVentana.setVisible(true);
        this.dispose();
    }

    private void jButton3_actionPerformed(ActionEvent e) {
        CrearArticulo nuevaVentana = new CrearArticulo();
        nuevaVentana.setVisible(true);
        this.dispose();
    }

    private void jButton4_actionPerformed(ActionEvent e) {
        VerEliminarArticulos nuevaVentana = new VerEliminarArticulos();
        nuevaVentana.setVisible(true);
        this.dispose();
    }

    //
    private void jButton11_actionPerformed(ActionEvent e) {
        this.FullRefresh();        
    }//End Method
    
    
    
    /*
     * ===================================================================================
     * Metodos definidos por el programador para
     * control de combobox en la aplicacion
     * ===================================================================================
     */
    
    //Configura comboboxes
    public void ConfiguraComponentes(){
        
        jComboBox14.addItemListener(new ItemListener() 
        {
           @Override
            public void itemStateChanged(ItemEvent event) {
               if (event.getStateChange() == ItemEvent.SELECTED) {
                  Object item = event.getItem();
                  // do something with object
                  FillAtributosDeArticulo(jTextField16,(String) item);
               }//End if
            }//End Method
        });//End Assignment
        jComboBox6.addItemListener(new ItemListener() 
        {
           @Override
            public void itemStateChanged(ItemEvent event) {
               if (event.getStateChange() == ItemEvent.SELECTED) {
                  Object item = event.getItem();
                  // do something with object
                  FillAtributosDeArticulo(jTextField17,(String) item);
               }//End if
            }//End Method
        });//End Assignment
        jComboBox5.addItemListener(new ItemListener() 
        {
           @Override
            public void itemStateChanged(ItemEvent event) {
               if (event.getStateChange() == ItemEvent.SELECTED) {
                  Object item = event.getItem();
                  // do something with object
                  FillAtributosDeArticulo(jTextField18,(String) item);
               }//End if
            }//End Method
        });//End Assignment
        
    }//End Method
    
    
    //Refresca todos los controles de la aplicacion
    public void FullRefresh(){
        this.limpiarTextFields();
        
        //Refresca las listas
        this.UpdateListaArticulos();
        
        //Refresca los comboboxes
        this.FillComboWithListaArticulos(jComboBox14);
        this.FillComboWithListaArticulos(jComboBox5);
        this.FillComboWithListaArticulos(jComboBox6);
        
        //Refresca las tablas
        this.UpdateTableWithListaArticulos(jTable2);
        
    }//End Method
    

    
    
    //Sincroniza la lista de articulos con la base de datos
    public void UpdateListaArticulos(){
        //Limpia la lista de basura
        this.lstArticulos.clear();
        //Define una variable tipo lista de articulos
        WsplsqlRowtypeSqx92118X1X2UserArray listaArticulos;
        //Obtiene la lista de articulos desde el webservice
        listaArticulos = WSPLSQLPortClient.listarArticulos();
        //Define bucle para extraer cada articulo de la lista
        for (WsplsqlRowtypeSqx92118X1X2User articulo : listaArticulos.getWsplsqlRowtypeSqx92118X1X2User()) {
            //Llena la lista
            this.lstArticulos.add(new ComboItem(articulo.getCodigo(), articulo.getDescripcion()));
        }//End For
    }//End Method
    
    
    
    
    //Muestra los atributos del articulo seleccionado
    public void FillAtributosDeArticulo(JTextField jText, String ArticuloSelected){
        //obtener el codigo del articulo seleccionado
        for (ComboItem item : this.lstArticulos){
            if (item.getDescripcion().equals(ArticuloSelected)){
                //obtener el resto de los datos desde la DB
                jText.setText(item.getCodigoStr());
            }//End IF
        }//End For
    }//End Method
    
    //Llena el combo con la lista de articulos
    public void FillComboWithListaArticulos(JComboBox jCombo){
        //Limpia el combo
        jCombo.removeAllItems();
        //Agrega objeto dummy al inicio
        jCombo.addItem("");
        //Define bucle para extraer cada articulo de la lista
        for (ComboItem articulo : this.lstArticulos) {
            //Llena el combobox
            jCombo.addItem(articulo.getDescripcion());
        }//End For
    }//End Method
    
    //LLena la tabla con la lista de articulos
    public void UpdateTableWithListaArticulos(JTable jMyTable){
        WsplsqlRowtypeSqx92118X1X2UserArray listaArticulos;
        listaArticulos = WSPLSQLPortClient.listarArticulos();
        String[] columnas = {"C�digo","Descripci�n","Precio (D�lares)"};
        DefaultTableModel model = new DefaultTableModel(columnas, 0);
        for (WsplsqlRowtypeSqx92118X1X2User articulo : listaArticulos.getWsplsqlRowtypeSqx92118X1X2User()) {
            Object[] row = new Object[3];
            row[0] = articulo.getCodigo();
            row[1] = articulo.getDescripcion();
            row[2] = articulo.getPreciomercdolares();
            model.addRow(row);
        }//End Method
        jMyTable.setModel(model);
        jMyTable.repaint();
    }//End Method
    
    //Limpia los combos de que muestran los atributos de un articulo
    public void limpiarTextFields(){
        jTextField114.setText("");
        jTextField113.setText("");
        jTextField112.setText("");
        jTextField111.setText("");
        jTextField110.setText("");
        jTextField23.setText("");
        jTextField22.setText("");
        
        jTextField18.setText("");
        jTextField17.setText("");
        
        
        
    }//End Method
    
    //Inserta un articulo
    public void insertarArticulo() {
        try {
            WSPLSQL3PortClient.Insertararticulo(jTextField114.getText(),
                                            jTextField113.getText(),
                                            new BigDecimal(1),
                                            new BigDecimal(1),
                                            jTextField22.getText(),
                                            new BigDecimal(1),
                                            new BigDecimal(1),
                                            "admin",
                                            new BigDecimal(jTextField112.getText()),
                                            new BigDecimal(jTextField111.getText()),
                                            new BigDecimal(jTextField110.getText()),
                                            new BigDecimal(jTextField23.getText()));
            JOptionPane.showMessageDialog(null, "Insertado, bien!!!");
        } catch (RemoteException e) {
            JOptionPane.showMessageDialog(null, "A mae, why not?");
        }
    }//end Method
    
    //actualiza el articulo
    public void actualizarArticulo(){
        try {
            WSPLSQL3PortClient.Modificararticulo(jTextField16.getText(), 
                                                 new BigDecimal(jTextField20.getText()));
            JOptionPane.showMessageDialog(null, "Modificado OK");
        } catch (RemoteException e) {
            JOptionPane.showMessageDialog(null, "Mae revise esa vara.");
        }
    }//End Method
    
    //borra el articulo
    public void borrarArticulo(){
        try {
            WSPLSQL3PortClient.Borrararticulo(jTextField16.getText());
            JOptionPane.showMessageDialog(null, "Borrado OK");
        } catch (RemoteException e) {
            JOptionPane.showMessageDialog(null, "Que raro, no pude borrarlo.");
        }
    }//End Method


    //Inserta un articulo en la tabla componentes
    public void insertarComponente(){
        try {
            WSPLSQL3PortClient.Insertarcomponente(jTextField18.getText(), jTextField17.getText());
            JOptionPane.showMessageDialog(null, "Insertado, bien!!!");
        } catch (RemoteException e) {
            JOptionPane.showMessageDialog(null, "A mae que mal.");
        }
    }//End Method


    public void borrarComponente(){
        try {
            WSPLSQL3PortClient.Borrarcomponente(jTextField18.getText(), jTextField17.getText());
            JOptionPane.showMessageDialog(null, "Borrado, bien!!!");
        } catch (RemoteException e) {
            JOptionPane.showMessageDialog(null, "A mae, why not?");
        }
    }//End Method

    
    /*
     * ===================================================================================
     * ===================================================================================
     */

    //Inserta un articulo
    private void jButton10_actionPerformed(ActionEvent e) {
        this.insertarArticulo();
        this.FullRefresh();
    }//End Method

    //Editar un articulo
    private void jButton9_actionPerformed(ActionEvent e) {
        this.actualizarArticulo();
        this.FullRefresh();
    }//End Method

    //Borrar un articulo
    private void jButton8_actionPerformed(ActionEvent e) {
        this.borrarArticulo();
        this.FullRefresh();
    }//End Method

    //Borrar un componente
    private void jButton16_actionPerformed(ActionEvent e) {
        this.borrarComponente();
        this.FullRefresh();
    }//End Method
}//End Class
