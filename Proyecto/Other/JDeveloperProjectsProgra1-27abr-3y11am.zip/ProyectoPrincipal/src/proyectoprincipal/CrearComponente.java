package proyectoprincipal;

import java.awt.Dimension;

import java.awt.Rectangle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;


//Cambio de linea
//import clienteWS.MyWSPortClient;
import clienteWS2.WSPLSQLPortClient;

public class CrearComponente extends JFrame {
    private JLabel jLabel1 = new JLabel();
    private JButton jButton1 = new JButton();
    private JLabel jLabel2 = new JLabel();
    private JComboBox jComboBox1 = new JComboBox();
    private JComboBox jComboBox2 = new JComboBox();
    private JButton jButton2 = new JButton();

    public CrearComponente() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout( null );
        this.setSize(new Dimension(432, 160));
        this.setTitle( "Crear Componente" );
        jLabel1.setText("Seleccione Nombre del Articulo:");
        jLabel1.setBounds(new Rectangle(60, 50, 160, 15));
        jButton1.setText("Crear Componente");
        jButton1.setBounds(new Rectangle(90, 95, 140, 20));
        jButton1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton1_actionPerformed(e);
                }
            });
        jLabel2.setText("Seleccione Nombre del Componente:");
        jLabel2.setBounds(new Rectangle(40, 20, 195, 15));
        jComboBox1.setBounds(new Rectangle(235, 15, 165, 20));
        jComboBox2.setBounds(new Rectangle(235, 45, 165, 20));
        jButton2.setText("Volver");
        jButton2.setBounds(new Rectangle(240, 95, 75, 21));
        jButton2.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    jButton2_actionPerformed(e);
                }
            });
        this.getContentPane().add(jButton2, null);
        this.getContentPane().add(jComboBox2, null);
        this.getContentPane().add(jComboBox1, null);
        this.getContentPane().add(jLabel2, null);
        this.getContentPane().add(jButton1, null);
        this.getContentPane().add(jLabel1, null);
    }

    private void jButton1_actionPerformed(ActionEvent e) {
        //Cambio de linea
        //MyWSPortClient.insertarComponente("FP110","SL02.8G08ME500SSD");
        WSPLSQLPortClient.insertarComponente("FP110","SL02.8G08ME500SSD");
    }

    private void jButton2_actionPerformed(ActionEvent e) {
        Principal nuevaVentana = new Principal();
        nuevaVentana.setVisible(true);
        this.dispose();
    }
}
