package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public class WsplsqlRowtypeSqx92118x6x2Base implements ORAData, ORADataFactory
{
 public static final String _SQL_NAME = "WSPLSQL_ROWTYPE_SQX92118X6X2";
  public static final int _SQL_TYPECODE = OracleTypes.STRUCT;

 protected MutableStruct _struct;

 protected static int[] _sqlType =  { 2,2,2,2,2,2,2 };
 protected static ORADataFactory[] _factory = new ORADataFactory[7];
 protected static final WsplsqlRowtypeSqx92118x6x2Base _WsplsqlRowtypeSqx92118x6x2BaseFactory = new WsplsqlRowtypeSqx92118x6x2Base();

 public static ORADataFactory getORADataFactory()
  { return _WsplsqlRowtypeSqx92118x6x2BaseFactory; }
 /* constructors */
 protected void _init_struct(boolean init)
 { if (init) _struct = new MutableStruct(new Object[7], _sqlType, _factory); }
 public WsplsqlRowtypeSqx92118x6x2Base()
 { _init_struct(true); }
 public WsplsqlRowtypeSqx92118x6x2Base(java.math.BigDecimal codmoneda1, java.math.BigDecimal codmoneda2, java.math.BigDecimal monto, java.math.BigDecimal codindiceeconomico, java.math.BigDecimal estado, java.math.BigDecimal mes, java.math.BigDecimal anio) throws SQLException
 { _init_struct(true);
 _setCodmoneda1(codmoneda1);
 _setCodmoneda2(codmoneda2);
 _setMonto(monto);
 _setCodindiceeconomico(codindiceeconomico);
 _setEstado(estado);
 _setMes(mes);
 _setAnio(anio);
  }

 /* ORAData interface */
 public Datum toDatum(Connection c) throws SQLException
  {
 _userSetterHelper();
    return _struct.toDatum(c, _SQL_NAME);
 }


 /* ORADataFactory interface */
 public ORAData create(Datum d, int sqlType) throws SQLException
 { return create(null, d, sqlType); }
 protected ORAData create(WsplsqlRowtypeSqx92118x6x2Base o, Datum d, int sqlType) throws SQLException
  {
 if (d == null) return null; 
    if (o == null) o = new WsplsqlRowtypeSqx92118x6x2User();
 o._struct = new MutableStruct((STRUCT) d, _sqlType, _factory);
    return o;
  }
 /* accessor methods */
 protected java.math.BigDecimal _getCodmoneda1() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(0); }

 protected void _setCodmoneda1(java.math.BigDecimal codmoneda1) throws SQLException
  { _struct.setAttribute(0, codmoneda1); }


 protected java.math.BigDecimal _getCodmoneda2() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(1); }

 protected void _setCodmoneda2(java.math.BigDecimal codmoneda2) throws SQLException
  { _struct.setAttribute(1, codmoneda2); }


 protected java.math.BigDecimal _getMonto() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(2); }

 protected void _setMonto(java.math.BigDecimal monto) throws SQLException
  { _struct.setAttribute(2, monto); }


 protected java.math.BigDecimal _getCodindiceeconomico() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(3); }

 protected void _setCodindiceeconomico(java.math.BigDecimal codindiceeconomico) throws SQLException
  { _struct.setAttribute(3, codindiceeconomico); }


 protected java.math.BigDecimal _getEstado() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(4); }

 protected void _setEstado(java.math.BigDecimal estado) throws SQLException
  { _struct.setAttribute(4, estado); }


 protected java.math.BigDecimal _getMes() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(5); }

 protected void _setMes(java.math.BigDecimal mes) throws SQLException
  { _struct.setAttribute(5, mes); }


 protected java.math.BigDecimal _getAnio() throws SQLException
 { return (java.math.BigDecimal) _struct.getAttribute(6); }

 protected void _setAnio(java.math.BigDecimal anio) throws SQLException
  { _struct.setAttribute(6, anio); }

;
  // Some setter action is delayed until toDatum() 
  // where the connection is available 
  void _userSetterHelper() throws java.sql.SQLException {} 
}
