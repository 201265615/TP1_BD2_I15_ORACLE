package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public interface WsplsqlRowtypeSqx92118x6x2 {

 public void setCodmoneda1(java.math.BigDecimal codmoneda1) throws SQLException;
 public java.math.BigDecimal getCodmoneda1() throws SQLException;

 public void setCodmoneda2(java.math.BigDecimal codmoneda2) throws SQLException;
 public java.math.BigDecimal getCodmoneda2() throws SQLException;

 public void setMonto(java.math.BigDecimal monto) throws SQLException;
 public java.math.BigDecimal getMonto() throws SQLException;

 public void setCodindiceeconomico(java.math.BigDecimal codindiceeconomico) throws SQLException;
 public java.math.BigDecimal getCodindiceeconomico() throws SQLException;

 public void setEstado(java.math.BigDecimal estado) throws SQLException;
 public java.math.BigDecimal getEstado() throws SQLException;

 public void setMes(java.math.BigDecimal mes) throws SQLException;
 public java.math.BigDecimal getMes() throws SQLException;

 public void setAnio(java.math.BigDecimal anio) throws SQLException;
 public java.math.BigDecimal getAnio() throws SQLException;


}
