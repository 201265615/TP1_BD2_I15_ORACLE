package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public class WsplsqlRowtypeSqx92118x5x2User extends WsplsqlRowtypeSqx92118x5x2Base implements ORAData, ORADataFactory, WsplsqlRowtypeSqx92118x5x2
{
 private static final WsplsqlRowtypeSqx92118x5x2User _WsplsqlRowtypeSqx92118x5x2UserFactory = new WsplsqlRowtypeSqx92118x5x2User();
 public static ORADataFactory getORADataFactory()
   { return _WsplsqlRowtypeSqx92118x5x2UserFactory; }

   public WsplsqlRowtypeSqx92118x5x2User() { super(); }
 public WsplsqlRowtypeSqx92118x5x2User(String codcomponente, String codarticulo) throws SQLException
 {
 _setCodcomponente(codcomponente);
 _setCodarticulo(codarticulo);
  }
 /* ORAData interface */
 public ORAData create(Datum d, int sqlType) throws SQLException
 { return create(new WsplsqlRowtypeSqx92118x5x2User(), d, sqlType); }

  /* superclass accessors */

 public void setCodcomponente(String codcomponente) throws SQLException { super._setCodcomponente(codcomponente); }
 public String getCodcomponente() throws SQLException { return super._getCodcomponente(); }


 public void setCodarticulo(String codarticulo) throws SQLException { super._setCodarticulo(codarticulo); }
 public String getCodarticulo() throws SQLException { return super._getCodarticulo(); }



}
