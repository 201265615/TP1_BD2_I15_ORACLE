package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public class WsplsqlRowtypeSqx92118x6x2User extends WsplsqlRowtypeSqx92118x6x2Base implements ORAData, ORADataFactory, WsplsqlRowtypeSqx92118x6x2
{
 private static final WsplsqlRowtypeSqx92118x6x2User _WsplsqlRowtypeSqx92118x6x2UserFactory = new WsplsqlRowtypeSqx92118x6x2User();
 public static ORADataFactory getORADataFactory()
   { return _WsplsqlRowtypeSqx92118x6x2UserFactory; }

   public WsplsqlRowtypeSqx92118x6x2User() { super(); }
 public WsplsqlRowtypeSqx92118x6x2User(java.math.BigDecimal codmoneda1, java.math.BigDecimal codmoneda2, java.math.BigDecimal monto, java.math.BigDecimal codindiceeconomico, java.math.BigDecimal estado, java.math.BigDecimal mes, java.math.BigDecimal anio) throws SQLException
 {
 _setCodmoneda1(codmoneda1);
 _setCodmoneda2(codmoneda2);
 _setMonto(monto);
 _setCodindiceeconomico(codindiceeconomico);
 _setEstado(estado);
 _setMes(mes);
 _setAnio(anio);
  }
 /* ORAData interface */
 public ORAData create(Datum d, int sqlType) throws SQLException
 { return create(new WsplsqlRowtypeSqx92118x6x2User(), d, sqlType); }

  /* superclass accessors */

 public void setCodmoneda1(java.math.BigDecimal codmoneda1) throws SQLException { super._setCodmoneda1(codmoneda1); }
 public java.math.BigDecimal getCodmoneda1() throws SQLException { return super._getCodmoneda1(); }


 public void setCodmoneda2(java.math.BigDecimal codmoneda2) throws SQLException { super._setCodmoneda2(codmoneda2); }
 public java.math.BigDecimal getCodmoneda2() throws SQLException { return super._getCodmoneda2(); }


 public void setMonto(java.math.BigDecimal monto) throws SQLException { super._setMonto(monto); }
 public java.math.BigDecimal getMonto() throws SQLException { return super._getMonto(); }


 public void setCodindiceeconomico(java.math.BigDecimal codindiceeconomico) throws SQLException { super._setCodindiceeconomico(codindiceeconomico); }
 public java.math.BigDecimal getCodindiceeconomico() throws SQLException { return super._getCodindiceeconomico(); }


 public void setEstado(java.math.BigDecimal estado) throws SQLException { super._setEstado(estado); }
 public java.math.BigDecimal getEstado() throws SQLException { return super._getEstado(); }


 public void setMes(java.math.BigDecimal mes) throws SQLException { super._setMes(mes); }
 public java.math.BigDecimal getMes() throws SQLException { return super._getMes(); }


 public void setAnio(java.math.BigDecimal anio) throws SQLException { super._setAnio(anio); }
 public java.math.BigDecimal getAnio() throws SQLException { return super._getAnio(); }



}
