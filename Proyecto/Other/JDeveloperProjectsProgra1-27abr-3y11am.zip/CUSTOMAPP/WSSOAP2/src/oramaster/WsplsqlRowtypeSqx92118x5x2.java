package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public interface WsplsqlRowtypeSqx92118x5x2 {

 public void setCodcomponente(String codcomponente) throws SQLException;
 public String getCodcomponente() throws SQLException;

 public void setCodarticulo(String codarticulo) throws SQLException;
 public String getCodarticulo() throws SQLException;


}
