package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import java.io.*;

public interface WSPLSQL3 extends java.rmi.Remote{


  public void spBorrararticulo(String inCodarticulo) throws java.rmi.RemoteException;
  public void spBorrarcomponente(String inCodcomponente, String inCodarticulo) throws java.rmi.RemoteException;
  public void spInsertararticulo(String inCodigo, String inDescripcion, java.math.BigDecimal inUndmedida, java.math.BigDecimal inCodmarca, String inModelo, java.math.BigDecimal inCodfamilia, java.math.BigDecimal inCodestarticulo, String inCoduserregistro, java.math.BigDecimal inCantidad, java.math.BigDecimal inCantmaxima, java.math.BigDecimal inCantminima, java.math.BigDecimal inPreciomercdolares) throws java.rmi.RemoteException;
  public void spInsertarcomponente(String inCodigocomponente, String inCodigoarticulo) throws java.rmi.RemoteException;
  public void spModificararticulo(String inCodigo, java.math.BigDecimal inPreciomercdolares) throws java.rmi.RemoteException;
  public void spModificarcomponente(String inCodcomponente, String inCodarticulo) throws java.rmi.RemoteException;
}
