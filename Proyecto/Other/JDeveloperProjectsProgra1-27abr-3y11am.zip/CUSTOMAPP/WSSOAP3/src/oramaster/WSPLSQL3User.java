package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import java.io.*;

public class WSPLSQL3User extends WSPLSQL3Base implements WSPLSQL3, java.rmi.Remote
{

 /* constructors */
 public WSPLSQL3User() throws SQLException  { super(); }
 public WSPLSQL3User(javax.sql.DataSource ds) throws SQLException { super(ds); }
 /* superclass methods */
  public void spBorrararticulo(String inCodarticulo) throws java.rmi.RemoteException
  { 
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
 String __jRt_2 = inCodarticulo;
    super._spBorrararticulo(__jRt_2, __onnScopeMethod);
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
  }
  public void spBorrarcomponente(String inCodcomponente, String inCodarticulo) throws java.rmi.RemoteException
  { 
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
 String __jRt_5 = inCodarticulo;
 String __jRt_4 = inCodcomponente;
    super._spBorrarcomponente(__jRt_4, __jRt_5, __onnScopeMethod);
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
  }
  public void spInsertararticulo(String inCodigo, String inDescripcion, java.math.BigDecimal inUndmedida, java.math.BigDecimal inCodmarca, String inModelo, java.math.BigDecimal inCodfamilia, java.math.BigDecimal inCodestarticulo, String inCoduserregistro, java.math.BigDecimal inCantidad, java.math.BigDecimal inCantmaxima, java.math.BigDecimal inCantminima, java.math.BigDecimal inPreciomercdolares) throws java.rmi.RemoteException
  { 
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
 java.math.BigDecimal __jRt_19 = inPreciomercdolares;
 java.math.BigDecimal __jRt_18 = inCantminima;
 java.math.BigDecimal __jRt_17 = inCantmaxima;
 java.math.BigDecimal __jRt_16 = inCantidad;
 String __jRt_15 = inCoduserregistro;
 java.math.BigDecimal __jRt_14 = inCodestarticulo;
 java.math.BigDecimal __jRt_13 = inCodfamilia;
 String __jRt_12 = inModelo;
 java.math.BigDecimal __jRt_11 = inCodmarca;
 java.math.BigDecimal __jRt_10 = inUndmedida;
 String __jRt_9 = inDescripcion;
 String __jRt_8 = inCodigo;
    super._spInsertararticulo(__jRt_8, __jRt_9, __jRt_10, __jRt_11, __jRt_12, __jRt_13, __jRt_14, __jRt_15, __jRt_16, __jRt_17, __jRt_18, __jRt_19, __onnScopeMethod);
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
  }
  public void spInsertarcomponente(String inCodigocomponente, String inCodigoarticulo) throws java.rmi.RemoteException
  { 
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
 String __jRt_33 = inCodigoarticulo;
 String __jRt_32 = inCodigocomponente;
    super._spInsertarcomponente(__jRt_32, __jRt_33, __onnScopeMethod);
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
  }
  public void spModificararticulo(String inCodigo, java.math.BigDecimal inPreciomercdolares) throws java.rmi.RemoteException
  { 
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
 java.math.BigDecimal __jRt_37 = inPreciomercdolares;
 String __jRt_36 = inCodigo;
    super._spModificararticulo(__jRt_36, __jRt_37, __onnScopeMethod);
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
  }
  public void spModificarcomponente(String inCodcomponente, String inCodarticulo) throws java.rmi.RemoteException
  { 
    try {
 java.sql.Connection __onnScopeMethod = __dataSource.getConnection();
 String __jRt_41 = inCodarticulo;
 String __jRt_40 = inCodcomponente;
    super._spModificarcomponente(__jRt_40, __jRt_41, __onnScopeMethod);
    __onnScopeMethod.close();

 } 
 catch (java.sql.SQLException except) {
 except.printStackTrace();
 throw new java.rmi.RemoteException(except.getClass().getName() + ": " + except.getMessage()); 
    }
  }
}
