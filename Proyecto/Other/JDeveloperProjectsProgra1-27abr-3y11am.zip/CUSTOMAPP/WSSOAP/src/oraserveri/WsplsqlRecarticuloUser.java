package oraserveri;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public class WsplsqlRecarticuloUser extends WsplsqlRecarticuloBase implements ORAData, ORADataFactory, WsplsqlRecarticulo
{
 private static final WsplsqlRecarticuloUser _WsplsqlRecarticuloUserFactory = new WsplsqlRecarticuloUser();
 public static ORADataFactory getORADataFactory()
   { return _WsplsqlRecarticuloUserFactory; }

   public WsplsqlRecarticuloUser() { super(); }
 public WsplsqlRecarticuloUser(String codigo, String descripcion) throws SQLException
 {
 _setCodigo(codigo);
 _setDescripcion(descripcion);
  }
 /* ORAData interface */
 public ORAData create(Datum d, int sqlType) throws SQLException
 { return create(new WsplsqlRecarticuloUser(), d, sqlType); }

  /* superclass accessors */

 public void setCodigo(String codigo) throws SQLException { super._setCodigo(codigo); }
 public String getCodigo() throws SQLException { return super._getCodigo(); }


 public void setDescripcion(String descripcion) throws SQLException { super._setDescripcion(descripcion); }
 public String getDescripcion() throws SQLException { return super._getDescripcion(); }



}
