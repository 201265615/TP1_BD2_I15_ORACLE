
package oramaster.wsplsql_wsdl.types;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WsplsqlRowtypeSqx92118x6x2User complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WsplsqlRowtypeSqx92118x6x2User">
 *   &lt;complexContent>
 *     &lt;extension base="{http://oramaster/WSPLSQL.wsdl/types/}WsplsqlRowtypeSqx92118x6x2Base">
 *       &lt;sequence>
 *         &lt;element name="anio" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="estado" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="mes" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="codindiceeconomico" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="codmoneda1" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="monto" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="codmoneda2" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WsplsqlRowtypeSqx92118x6x2User", propOrder = {
    "anio",
    "estado",
    "mes",
    "codindiceeconomico",
    "codmoneda1",
    "monto",
    "codmoneda2"
})
public class WsplsqlRowtypeSqx92118X6X2User
    extends WsplsqlRowtypeSqx92118X6X2Base
{

    @XmlElement(required = true, nillable = true)
    protected BigDecimal anio;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal estado;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal mes;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal codindiceeconomico;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal codmoneda1;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal monto;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal codmoneda2;

    /**
     * Gets the value of the anio property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAnio() {
        return anio;
    }

    /**
     * Sets the value of the anio property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAnio(BigDecimal value) {
        this.anio = value;
    }

    /**
     * Gets the value of the estado property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getEstado() {
        return estado;
    }

    /**
     * Sets the value of the estado property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setEstado(BigDecimal value) {
        this.estado = value;
    }

    /**
     * Gets the value of the mes property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMes() {
        return mes;
    }

    /**
     * Sets the value of the mes property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMes(BigDecimal value) {
        this.mes = value;
    }

    /**
     * Gets the value of the codindiceeconomico property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCodindiceeconomico() {
        return codindiceeconomico;
    }

    /**
     * Sets the value of the codindiceeconomico property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCodindiceeconomico(BigDecimal value) {
        this.codindiceeconomico = value;
    }

    /**
     * Gets the value of the codmoneda1 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCodmoneda1() {
        return codmoneda1;
    }

    /**
     * Sets the value of the codmoneda1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCodmoneda1(BigDecimal value) {
        this.codmoneda1 = value;
    }

    /**
     * Gets the value of the monto property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMonto() {
        return monto;
    }

    /**
     * Sets the value of the monto property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMonto(BigDecimal value) {
        this.monto = value;
    }

    /**
     * Gets the value of the codmoneda2 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCodmoneda2() {
        return codmoneda2;
    }

    /**
     * Sets the value of the codmoneda2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCodmoneda2(BigDecimal value) {
        this.codmoneda2 = value;
    }

}
