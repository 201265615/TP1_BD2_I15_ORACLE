@javax.xml.bind.annotation.XmlSchema(namespace = "http://oraserveri/WSPLSQL.wsdl/types/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package oraserveri.wsplsql_wsdl.types;
