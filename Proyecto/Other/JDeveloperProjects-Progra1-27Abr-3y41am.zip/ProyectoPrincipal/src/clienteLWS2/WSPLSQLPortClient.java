package clienteLWS2;

import oramaster.wsplsql_wsdl.types.*;

public class WSPLSQLPortClient
{
  public static void main(String [] args)
  {
    //WSPLSQL_Service wSPLSQL_Service = new WSPLSQL_Service();
    //WSPLSQL wSPLSQL = wSPLSQL_Service.getWSPLSQLPort();
    // Add your code to call the desired methods.
  }

    public static WsplsqlRowtypeSqx92118X1X2UserArray listarArticulos(){
        WSPLSQL_Service wSPLSQL_Service = new WSPLSQL_Service();
        WSPLSQL wSPLSQL = wSPLSQL_Service.getWSPLSQLPort();
        return wSPLSQL.listarticulos();
    }//End Method

    public static WsplsqlRowtypeSqx92118X5X2UserArray listarComponentes(){
        WSPLSQL_Service wSPLSQL_Service = new WSPLSQL_Service();
        WSPLSQL wSPLSQL = wSPLSQL_Service.getWSPLSQLPort();
        return wSPLSQL.listcomponentes();
    }//End Method
    
    public static WsplsqlRowtypeSqx92118X4X2UserArray listarFamilias(){
        WSPLSQL_Service wSPLSQL_Service = new WSPLSQL_Service();
        WSPLSQL wSPLSQL = wSPLSQL_Service.getWSPLSQLPort();
        return wSPLSQL.listfamilias();
    }//End Method
    
    public static WsplsqlRowtypeSqx92118X3X2UserArray listarMarcas(){
        WSPLSQL_Service wSPLSQL_Service = new WSPLSQL_Service();
        WSPLSQL wSPLSQL = wSPLSQL_Service.getWSPLSQLPort();
        return wSPLSQL.listmarcas();
    }//End Method
    

    public static WsplsqlRowtypeSqx92118X7X2UserArray listarProyListaPrecios(){
        WSPLSQL_Service wSPLSQL_Service = new WSPLSQL_Service();
        WSPLSQL wSPLSQL = wSPLSQL_Service.getWSPLSQLPort();
        return wSPLSQL.listproylistaprecios();
    }//End Method
    
    public static WsplsqlRowtypeSqx92118X6X2UserArray listarTipoCambios(){
        WSPLSQL_Service wSPLSQL_Service = new WSPLSQL_Service();
        WSPLSQL wSPLSQL = wSPLSQL_Service.getWSPLSQLPort();
        return wSPLSQL.listtipocambios();
    }//End Method
    
    public static WsplsqlRowtypeSqx92118X2X2UserArray listarUndMedidas(){
        WSPLSQL_Service wSPLSQL_Service = new WSPLSQL_Service();
        WSPLSQL wSPLSQL = wSPLSQL_Service.getWSPLSQLPort();
        return wSPLSQL.listunidmedidas();
    }//End Method

  
  
}
