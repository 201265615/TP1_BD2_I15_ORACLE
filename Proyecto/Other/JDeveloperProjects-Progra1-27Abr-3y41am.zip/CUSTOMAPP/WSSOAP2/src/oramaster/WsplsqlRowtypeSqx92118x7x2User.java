package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public class WsplsqlRowtypeSqx92118x7x2User extends WsplsqlRowtypeSqx92118x7x2Base implements ORAData, ORADataFactory, WsplsqlRowtypeSqx92118x7x2
{
 private static final WsplsqlRowtypeSqx92118x7x2User _WsplsqlRowtypeSqx92118x7x2UserFactory = new WsplsqlRowtypeSqx92118x7x2User();
 public static ORADataFactory getORADataFactory()
   { return _WsplsqlRowtypeSqx92118x7x2UserFactory; }

   public WsplsqlRowtypeSqx92118x7x2User() { super(); }
 public WsplsqlRowtypeSqx92118x7x2User(String codarticulo, java.math.BigDecimal codlistaprecios, java.math.BigDecimal mes, java.math.BigDecimal anio, java.math.BigDecimal tipocambioproyect, java.math.BigDecimal preciomercdolaresproyect) throws SQLException
 {
 _setCodarticulo(codarticulo);
 _setCodlistaprecios(codlistaprecios);
 _setMes(mes);
 _setAnio(anio);
 _setTipocambioproyect(tipocambioproyect);
 _setPreciomercdolaresproyect(preciomercdolaresproyect);
  }
 /* ORAData interface */
 public ORAData create(Datum d, int sqlType) throws SQLException
 { return create(new WsplsqlRowtypeSqx92118x7x2User(), d, sqlType); }

  /* superclass accessors */

 public void setCodarticulo(String codarticulo) throws SQLException { super._setCodarticulo(codarticulo); }
 public String getCodarticulo() throws SQLException { return super._getCodarticulo(); }


 public void setCodlistaprecios(java.math.BigDecimal codlistaprecios) throws SQLException { super._setCodlistaprecios(codlistaprecios); }
 public java.math.BigDecimal getCodlistaprecios() throws SQLException { return super._getCodlistaprecios(); }


 public void setMes(java.math.BigDecimal mes) throws SQLException { super._setMes(mes); }
 public java.math.BigDecimal getMes() throws SQLException { return super._getMes(); }


 public void setAnio(java.math.BigDecimal anio) throws SQLException { super._setAnio(anio); }
 public java.math.BigDecimal getAnio() throws SQLException { return super._getAnio(); }


 public void setTipocambioproyect(java.math.BigDecimal tipocambioproyect) throws SQLException { super._setTipocambioproyect(tipocambioproyect); }
 public java.math.BigDecimal getTipocambioproyect() throws SQLException { return super._getTipocambioproyect(); }


 public void setPreciomercdolaresproyect(java.math.BigDecimal preciomercdolaresproyect) throws SQLException { super._setPreciomercdolaresproyect(preciomercdolaresproyect); }
 public java.math.BigDecimal getPreciomercdolaresproyect() throws SQLException { return super._getPreciomercdolaresproyect(); }



}
