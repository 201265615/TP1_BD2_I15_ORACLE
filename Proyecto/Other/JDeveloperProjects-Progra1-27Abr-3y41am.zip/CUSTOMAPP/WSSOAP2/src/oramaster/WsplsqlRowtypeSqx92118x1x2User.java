package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public class WsplsqlRowtypeSqx92118x1x2User extends WsplsqlRowtypeSqx92118x1x2Base implements ORAData, ORADataFactory, WsplsqlRowtypeSqx92118x1x2
{
 private static final WsplsqlRowtypeSqx92118x1x2User _WsplsqlRowtypeSqx92118x1x2UserFactory = new WsplsqlRowtypeSqx92118x1x2User();
 public static ORADataFactory getORADataFactory()
   { return _WsplsqlRowtypeSqx92118x1x2UserFactory; }

   public WsplsqlRowtypeSqx92118x1x2User() { super(); }
 public WsplsqlRowtypeSqx92118x1x2User(String codigo, String descripcion, java.math.BigDecimal undmedida, java.math.BigDecimal codmarca, String modelo, java.util.Calendar fecregistro, java.math.BigDecimal codfamilia, java.math.BigDecimal codestarticulo, String coduserregistro, java.math.BigDecimal cantidad, java.math.BigDecimal cantmaxima, java.math.BigDecimal cantminima, java.math.BigDecimal preciomercdolares, java.util.Calendar fechaactprecio) throws SQLException
 {
 _setCodigo(codigo);
 _setDescripcion(descripcion);
 _setUndmedida(undmedida);
 _setCodmarca(codmarca);
 _setModelo(modelo);
 java.sql.Timestamp __jPt_5;
    // Converting Calendar to Timestamp
    __jPt_5 = null;
    if (fecregistro!=null) __jPt_5 = new java.sql.Timestamp(fecregistro.getTimeInMillis());
 _setFecregistro(__jPt_5);
 _setCodfamilia(codfamilia);
 _setCodestarticulo(codestarticulo);
 _setCoduserregistro(coduserregistro);
 _setCantidad(cantidad);
 _setCantmaxima(cantmaxima);
 _setCantminima(cantminima);
 _setPreciomercdolares(preciomercdolares);
 java.sql.Timestamp __jPt_13;
    // Converting Calendar to Timestamp
    __jPt_13 = null;
    if (fechaactprecio!=null) __jPt_13 = new java.sql.Timestamp(fechaactprecio.getTimeInMillis());
 _setFechaactprecio(__jPt_13);
  }
 /* ORAData interface */
 public ORAData create(Datum d, int sqlType) throws SQLException
 { return create(new WsplsqlRowtypeSqx92118x1x2User(), d, sqlType); }

  /* superclass accessors */

 public void setCodigo(String codigo) throws SQLException { super._setCodigo(codigo); }
 public String getCodigo() throws SQLException { return super._getCodigo(); }


 public void setDescripcion(String descripcion) throws SQLException { super._setDescripcion(descripcion); }
 public String getDescripcion() throws SQLException { return super._getDescripcion(); }


 public void setUndmedida(java.math.BigDecimal undmedida) throws SQLException { super._setUndmedida(undmedida); }
 public java.math.BigDecimal getUndmedida() throws SQLException { return super._getUndmedida(); }


 public void setCodmarca(java.math.BigDecimal codmarca) throws SQLException { super._setCodmarca(codmarca); }
 public java.math.BigDecimal getCodmarca() throws SQLException { return super._getCodmarca(); }


 public void setModelo(String modelo) throws SQLException { super._setModelo(modelo); }
 public String getModelo() throws SQLException { return super._getModelo(); }


 public void setFecregistro(java.util.Calendar fecregistro) throws SQLException { 
 java.sql.Timestamp __jPt_0;
    // Converting Calendar to Timestamp
    __jPt_0 = null;
    if (fecregistro!=null) __jPt_0 = new java.sql.Timestamp(fecregistro.getTimeInMillis());
   super._setFecregistro(__jPt_0); 
  }
 public java.util.Calendar getFecregistro() throws SQLException { 
 java.sql.Timestamp __jRt_0;
 __jRt_0 = super._getFecregistro(); 
 java.util.Calendar __jRt_1;
    __jRt_1 = null;
    if (__jRt_0!=null) 
    {
      __jRt_1 = java.util.Calendar.getInstance();
      __jRt_1.setTimeInMillis(__jRt_0.getTime());
    }
    return __jRt_1; 
  }


 public void setCodfamilia(java.math.BigDecimal codfamilia) throws SQLException { super._setCodfamilia(codfamilia); }
 public java.math.BigDecimal getCodfamilia() throws SQLException { return super._getCodfamilia(); }


 public void setCodestarticulo(java.math.BigDecimal codestarticulo) throws SQLException { super._setCodestarticulo(codestarticulo); }
 public java.math.BigDecimal getCodestarticulo() throws SQLException { return super._getCodestarticulo(); }


 public void setCoduserregistro(String coduserregistro) throws SQLException { super._setCoduserregistro(coduserregistro); }
 public String getCoduserregistro() throws SQLException { return super._getCoduserregistro(); }


 public void setCantidad(java.math.BigDecimal cantidad) throws SQLException { super._setCantidad(cantidad); }
 public java.math.BigDecimal getCantidad() throws SQLException { return super._getCantidad(); }


 public void setCantmaxima(java.math.BigDecimal cantmaxima) throws SQLException { super._setCantmaxima(cantmaxima); }
 public java.math.BigDecimal getCantmaxima() throws SQLException { return super._getCantmaxima(); }


 public void setCantminima(java.math.BigDecimal cantminima) throws SQLException { super._setCantminima(cantminima); }
 public java.math.BigDecimal getCantminima() throws SQLException { return super._getCantminima(); }


 public void setPreciomercdolares(java.math.BigDecimal preciomercdolares) throws SQLException { super._setPreciomercdolares(preciomercdolares); }
 public java.math.BigDecimal getPreciomercdolares() throws SQLException { return super._getPreciomercdolares(); }


 public void setFechaactprecio(java.util.Calendar fechaactprecio) throws SQLException { 
 java.sql.Timestamp __jPt_0;
    // Converting Calendar to Timestamp
    __jPt_0 = null;
    if (fechaactprecio!=null) __jPt_0 = new java.sql.Timestamp(fechaactprecio.getTimeInMillis());
   super._setFechaactprecio(__jPt_0); 
  }
 public java.util.Calendar getFechaactprecio() throws SQLException { 
 java.sql.Timestamp __jRt_0;
 __jRt_0 = super._getFechaactprecio(); 
 java.util.Calendar __jRt_1;
    __jRt_1 = null;
    if (__jRt_0!=null) 
    {
      __jRt_1 = java.util.Calendar.getInstance();
      __jRt_1.setTimeInMillis(__jRt_0.getTime());
    }
    return __jRt_1; 
  }



}
