package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;
import oracle.jpub.runtime.MutableStruct;
import java.io.*;

public interface WsplsqlRowtypeSqx92118x7x2 {

 public void setCodarticulo(String codarticulo) throws SQLException;
 public String getCodarticulo() throws SQLException;

 public void setCodlistaprecios(java.math.BigDecimal codlistaprecios) throws SQLException;
 public java.math.BigDecimal getCodlistaprecios() throws SQLException;

 public void setMes(java.math.BigDecimal mes) throws SQLException;
 public java.math.BigDecimal getMes() throws SQLException;

 public void setAnio(java.math.BigDecimal anio) throws SQLException;
 public java.math.BigDecimal getAnio() throws SQLException;

 public void setTipocambioproyect(java.math.BigDecimal tipocambioproyect) throws SQLException;
 public java.math.BigDecimal getTipocambioproyect() throws SQLException;

 public void setPreciomercdolaresproyect(java.math.BigDecimal preciomercdolaresproyect) throws SQLException;
 public java.math.BigDecimal getPreciomercdolaresproyect() throws SQLException;


}
