package oramaster;

import java.sql.SQLException;
import java.sql.Connection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.Datum;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.jpub.runtime.MutableArray;

public class WsplsqlArrunidmedidas implements ORAData, ORADataFactory
{
 public static final String _SQL_NAME = "WSPLSQL_ARRUNIDMEDIDAS";
  public static final int _SQL_TYPECODE = OracleTypes.ARRAY;

 MutableArray _array;

transient Connection con;

private static final WsplsqlArrunidmedidas _WsplsqlArrunidmedidasFactory = new WsplsqlArrunidmedidas();

 public static ORADataFactory getORADataFactory()
  { return _WsplsqlArrunidmedidasFactory; }
 /* constructors */
 public WsplsqlArrunidmedidas()
 {
    this(new WsplsqlRowtypeSqx92118x2x2User[0]);
 }

 public WsplsqlArrunidmedidas(WsplsqlRowtypeSqx92118x2x2User[] a)
 {
    try {
    _array = new MutableArray(2002, a, WsplsqlRowtypeSqx92118x2x2User.getORADataFactory());
 array = a;
    } catch (Exception ex) {
      ex.printStackTrace();
    }
 }

 /* ORAData interface */
 public Datum toDatum(Connection c) throws SQLException
  {
this.con = c; if (array!=null) _setArray(array);
 if (array!=null) array = null;
    if (__schemaName!=null) return _array.toDatum(c,__schemaName + "." + _SQL_NAME);
    return _array.toDatum(c, _SQL_NAME);
 }
 private String __schemaName = null;
  public void __setSchemaName(String schemaName) { __schemaName = schemaName; }

  /* ORADataFactory interface */
  public ORAData create(Datum d, int sqlType) throws SQLException
  {
    if (d == null) return null; 
    WsplsqlArrunidmedidas a = new WsplsqlArrunidmedidas();
 a._array = new MutableArray(2002, (ARRAY) d, WsplsqlRowtypeSqx92118x2x2User.getORADataFactory());
 a.array = null;
    return a;
 }

 public int length() throws SQLException
 {
 return _array.length();
 }

 public int _getBaseType() throws SQLException
 {
 return _array.getBaseType();
 }

 public String _getBaseTypeName() throws SQLException
 {
 return _array.getBaseTypeName();
 }

 private Connection _getConnection() {return con;}


 /* array accessor methods */
  public WsplsqlRowtypeSqx92118x2x2User[] getArray() throws SQLException
  {
    if (array!=null) { return array; }
    return array=(WsplsqlRowtypeSqx92118x2x2User[]) _array.getObjectArray(
      new WsplsqlRowtypeSqx92118x2x2User[_array.length()]);
  }

  public WsplsqlRowtypeSqx92118x2x2User[] getArray(long index, int count) throws SQLException
 {
 if (array!=null) { _setArray(array); array = null; }
    return (WsplsqlRowtypeSqx92118x2x2User[]) _array.getObjectArray(index,
      new WsplsqlRowtypeSqx92118x2x2User[_array.sliceLength(index, count)]);
  }

 private WsplsqlRowtypeSqx92118x2x2User[] array;
 public void setArray(WsplsqlRowtypeSqx92118x2x2User[] a) { array = a; };
 public void _setArray(WsplsqlRowtypeSqx92118x2x2User[] a) throws SQLException
  {
    _array.setObjectArray(a);
  }

  public void setArray(WsplsqlRowtypeSqx92118x2x2User[] a, long index) throws SQLException
 {
 if (array!=null) { _setArray(array); array = null; }
    _array.setObjectArray(a, index);
  }

 public WsplsqlRowtypeSqx92118x2x2User _getElement(long index) throws SQLException
 {
 if (array!=null) { _setArray(array); array = null; }
 return (WsplsqlRowtypeSqx92118x2x2User) _array.getObjectElement(index);
 }

 public void _setElement(WsplsqlRowtypeSqx92118x2x2User a, long index) throws SQLException
 {
 if (array!=null) { _setArray(array); array = null; }
 _array.setObjectElement(a, index);
 }

}
